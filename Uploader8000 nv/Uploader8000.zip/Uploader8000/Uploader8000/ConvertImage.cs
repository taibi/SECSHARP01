﻿using System;
using System.IO;
using System.Text;

namespace Uploader8000
{
    public class ConvertImage
    {
        private ConvertImage() { }

        #region Constants

        const byte IX_IMG_COMPRESSION = 0x00;
        const byte IX_COLOR_DEPTH = 0x01;
        const byte IX_IMG_HEIGHT_1 = 0x02;
        const byte IX_IMG_HEIGHT_2 = 0x03;
        const byte IX_IMG_WIDTH_1 = 0x04;
        const byte IX_IMG_WIDTH_2 = 0x05;
        const byte IX_IMG_ADDR_START_PIX = 0x06;
        const byte IMG_HEADER_NB_BYTES = 0x06;

        const byte IX_BMP_IMG_SIZE_1 = 0x02;
        const byte IX_BMP_IMG_SIZE_2 = 0x03;
        const byte IX_BMP_IMG_SIZE_3 = 0x04;
        const byte IX_BMP_IMG_SIZE_4 = 0x05;
        const byte IX_BMP_IMG_OFFSET_PIX_1 = 0x0A;
        const byte IX_BMP_IMG_OFFSET_PIX_2 = 0x0B;
        const byte IX_BMP_IMG_OFFSET_PIX_3 = 0x0C;
        const byte IX_BMP_IMG_OFFSET_PIX_4 = 0x0D;

        const byte IX_BMP_IMG_SIZE_DBID_1 = 0x0E;
        const byte IX_BMP_IMG_SIZE_DBID_2 = 0x0F;
        const byte IX_BMP_IMG_SIZE_DBID_3 = 0x10;
        const byte IX_BMP_IMG_SIZE_DBID_4 = 0x11;

        const byte IX_BMP_IMG_WIDTH_1 = 0x12;
        const byte IX_BMP_IMG_WIDTH_2 = 0x13;
        const byte IX_BMP_IMG_WIDTH_3 = 0x14;
        const byte IX_BMP_IMG_WIDTH_4 = 0x15;
        const byte IX_BMP_IMG_HEIGHT_1 = 0x16;
        const byte IX_BMP_IMG_HEIGHT_2 = 0x17;
        const byte IX_BMP_IMG_HEIGHT_3 = 0x18;
        const byte IX_BMP_IMG_HEIGHT_4 = 0x19;
        const byte IX_BMP_COLOR_DEPTH_1 = 0x1C;
        const byte IX_BMP_COLOR_DEPTH_2 = 0x1D;
        const byte IX_BMP_IMG_COMP_1 = 0x1E;
        const byte IX_BMP_IMG_COMP_2 = 0x1F;
        const byte IX_BMP_IMG_COMP_3 = 0x20;
        const byte IX_BMP_IMG_COMP_4 = 0x21;

        const byte IX_BMP_IMG_SIZE_RAW_DATA_1 = 0x22;
        const byte IX_BMP_IMG_SIZE_RAW_DATA_2 = 0x23;
        const byte IX_BMP_IMG_SIZE_RAW_DATA_3 = 0x24;
        const byte IX_BMP_IMG_SIZE_RAW_DATA_4 = 0x25;

        #endregion

        /// <summary>
        /// Read the image and prepare parameters to convert it in a binary file.
        /// <param name="stream">File stream Information </param>
        /// <param name="inputFile">Input file name</param>
        /// <param name="outputDirectory">Output file name</param>
        /// <returns>Image information to be converted in binary file</returns>
        /// </summary>
        public static ImageInfo ConstructImageForConversion(Stream stream, String inputFile, String outputDirectory)
        {
            ImageInfo imageInfo = new ImageInfo();

            try
            {
                DefineGlobalVarParameter(ref imageInfo, stream, inputFile, outputDirectory);
                GetBmpInformation(ref imageInfo);
                ValidateImageProperties(ref imageInfo);

                if (imageInfo.FileFormat == GlobalError.FILE_NO_ERROR)
                {
                    PrepareImageForConversion(ref imageInfo);
                }
                else
                {
                    ConstructErrorMessage(ref imageInfo);
                }
            }
            catch (Exception)
            {
                imageInfo.Message = "Error : Unable to read image information";
            }

            return imageInfo;
        }

        /// <summary>
        /// Convert the image to a binary file
        /// <param name="imageInfo">Image information to be converted in binary file</param>
        /// <returns>True if the conversion is suvccessful otherwise false</returns>
        /// </summary>
        public static bool CreateBinaryFile(ImageInfo imageInfo)
        {
            bool status = true;

            try
            {
                string fileNameBin = imageInfo.InputFileName + ".bin";
                string pathStringBin = System.IO.Path.Combine(imageInfo.FolderOutputPath, fileNameBin);

                using (System.IO.FileStream fs = System.IO.File.Create(pathStringBin))
                {
                    System.IO.Path.Combine(imageInfo.FolderOutputPath, fileNameBin);
                    fs.Write(imageInfo.ByteArrayOutput, 0, (int)imageInfo.ImageOutput.Size);
                }
            }
            catch (Exception)
            {
                status = false;
            }

            return status;
        }

        /// <summary>
        /// Define the class that will contain all image information to be converted in binary
        /// <param name="imageInfo">Image information to be converted in binary file</param>
        /// <param name="fileStream">File stream Information </param>
        /// </summary>
        private static void DefineGlobalVarParameter(ref ImageInfo imageInfo, Stream stream, String inputFile, String outputDirectory)
        {
            imageInfo.FileFormat = GlobalError.FILE_NO_ERROR;
            imageInfo.ByteArrayBMP = new byte[stream.Length];
            imageInfo.ByteArrayOutput = new byte[stream.Length];

            // Read every byte of the image
            using (BinaryReader reader = new BinaryReader(stream, new ASCIIEncoding()))
            {
                long temp = stream.Length;

                for (long i = 0; i < stream.Length; i++)
                {
                    imageInfo.ByteArrayBMP[i] = reader.ReadByte();
                }
            }

            imageInfo.ByteArrayOutput[IX_IMG_COMPRESSION] = imageInfo.ByteArrayBMP[IX_BMP_IMG_COMP_1];
            imageInfo.ByteArrayOutput[IX_COLOR_DEPTH] = 16;         //Color Depth hardcode to 16 bits
            imageInfo.ByteArrayOutput[IX_IMG_WIDTH_1] = imageInfo.ByteArrayBMP[IX_BMP_IMG_WIDTH_1];
            imageInfo.ByteArrayOutput[IX_IMG_WIDTH_2] = imageInfo.ByteArrayBMP[IX_BMP_IMG_WIDTH_2];
            imageInfo.ByteArrayOutput[IX_IMG_HEIGHT_1] = imageInfo.ByteArrayBMP[IX_BMP_IMG_HEIGHT_1];
            imageInfo.ByteArrayOutput[IX_IMG_HEIGHT_2] = imageInfo.ByteArrayBMP[IX_BMP_IMG_HEIGHT_2];

            imageInfo.ImageOutput.Compression = imageInfo.ByteArrayBMP[IX_BMP_IMG_COMP_1];
            imageInfo.ImageOutput.ColorDepth = imageInfo.ByteArrayOutput[IX_COLOR_DEPTH];
            imageInfo.ImageOutput.Width = (uint)imageInfo.ByteArrayOutput[IX_IMG_WIDTH_1] + (uint)(imageInfo.ByteArrayOutput[IX_IMG_WIDTH_2] << 8);
            imageInfo.ImageOutput.Height = (uint)imageInfo.ByteArrayOutput[IX_IMG_HEIGHT_1] + (uint)(imageInfo.ByteArrayOutput[IX_IMG_HEIGHT_2] << 8);
            imageInfo.ImageOutput.Size = IMG_HEADER_NB_BYTES + (imageInfo.ImageOutput.Width * imageInfo.ImageOutput.Height * 2);

            imageInfo.InputFileName = System.IO.Path.GetFileNameWithoutExtension(inputFile);
            imageInfo.FileFormat = GlobalError.FILE_NO_ERROR;
            imageInfo.FolderOutputPath = outputDirectory;
        }

        /// <summary>
        /// Get the BMP properties
        /// <param name="imageInfo">Image information to be converted in binary file</param>
        /// <param name="ImaBMP">Image properties</param>
        /// <param name="fileStream">File stream Information</param>
        /// </summary>
        private static void GetBmpInformation(ref ImageInfo imageInfo)
        {
            imageInfo.ImageBMP.Size = (uint)imageInfo.ByteArrayBMP[IX_BMP_IMG_SIZE_1] + (uint)(imageInfo.ByteArrayBMP[IX_BMP_IMG_SIZE_2] << 8) + (uint)(imageInfo.ByteArrayBMP[IX_BMP_IMG_SIZE_3] << 16) + (uint)(imageInfo.ByteArrayBMP[IX_BMP_IMG_SIZE_4] << 24);
            imageInfo.ImageBMP.OffsetPixelArray = (uint)imageInfo.ByteArrayBMP[IX_BMP_IMG_OFFSET_PIX_1] + (uint)(imageInfo.ByteArrayBMP[IX_BMP_IMG_OFFSET_PIX_2] << 8) + (uint)(imageInfo.ByteArrayBMP[IX_BMP_IMG_OFFSET_PIX_3] << 16) + (uint)(imageInfo.ByteArrayBMP[IX_BMP_IMG_OFFSET_PIX_4] << 24);
            imageInfo.ImageBMP.SizeDbid = (uint)imageInfo.ByteArrayBMP[IX_BMP_IMG_SIZE_DBID_1] + (uint)(imageInfo.ByteArrayBMP[IX_BMP_IMG_SIZE_DBID_2] << 8) + (uint)(imageInfo.ByteArrayBMP[IX_BMP_IMG_SIZE_DBID_3] << 16) + (uint)(imageInfo.ByteArrayBMP[IX_BMP_IMG_SIZE_DBID_4] << 24);
            imageInfo.ImageBMP.Width = (uint)imageInfo.ByteArrayBMP[IX_BMP_IMG_WIDTH_1] + (uint)(imageInfo.ByteArrayBMP[IX_BMP_IMG_WIDTH_2] << 8) + (uint)(imageInfo.ByteArrayBMP[IX_BMP_IMG_WIDTH_3] << 16) + (uint)(imageInfo.ByteArrayBMP[IX_BMP_IMG_WIDTH_4] << 24);
            imageInfo.ImageBMP.Heigth = (uint)imageInfo.ByteArrayBMP[IX_BMP_IMG_HEIGHT_1] + (uint)(imageInfo.ByteArrayBMP[IX_BMP_IMG_HEIGHT_2] << 8) + (uint)(imageInfo.ByteArrayBMP[IX_BMP_IMG_HEIGHT_3] << 16) + (uint)(imageInfo.ByteArrayBMP[IX_BMP_IMG_HEIGHT_4] << 24);
            imageInfo.ImageBMP.ColorDepth = (uint)imageInfo.ByteArrayBMP[IX_BMP_COLOR_DEPTH_1] + (uint)(imageInfo.ByteArrayBMP[IX_BMP_COLOR_DEPTH_2] << 8);
            imageInfo.ImageBMP.Compression = (uint)imageInfo.ByteArrayBMP[IX_BMP_IMG_COMP_1] + (uint)(imageInfo.ByteArrayBMP[IX_BMP_IMG_COMP_2] << 8) + (uint)(imageInfo.ByteArrayBMP[IX_BMP_IMG_COMP_3] << 16) + (uint)(imageInfo.ByteArrayBMP[IX_BMP_IMG_COMP_4] << 24);
            imageInfo.ImageBMP.SizeRawData = (uint)imageInfo.ByteArrayBMP[IX_BMP_IMG_SIZE_RAW_DATA_1] + (uint)(imageInfo.ByteArrayBMP[IX_BMP_IMG_SIZE_RAW_DATA_2] << 8) + (uint)(imageInfo.ByteArrayBMP[IX_BMP_IMG_SIZE_RAW_DATA_3] << 16) + (uint)(imageInfo.ByteArrayBMP[IX_BMP_IMG_SIZE_RAW_DATA_4] << 24);
        }

        /// <summary>
        /// Prepare the image information to be conformed to the Microchip 
        /// format by calculing intermidiate values
        /// <param name="imageInfo">Image information to be converted in binary file</param>
        /// <param name="ImaBMP">Image properties</param>
        /// <param name="inputFile">Name of the image</param>
        /// <param name="outputDirectory">Name of the binary</param>
        /// </summary>
        private static void PrepareImageForConversion(ref ImageInfo imageInfo)
        {
            // Divide by 4 for padding alignment
            uint imageWidth = (imageInfo.ImageBMP.Width * 3) / 4;

            // Evaluate a new padding when it is not a multiple of 4
            uint PaddingAlignNbBytes = 0;
            if ((imageInfo.ImageBMP.Width * 3) % 4 != 0)
            {
                imageWidth += 1;   // +1 for superior mutiltiple of 4.
                PaddingAlignNbBytes = (imageWidth * 4) - (imageInfo.ImageBMP.Width * 3);
            }

            //Find number of bytes for each row including the padding bytes.
            uint ImageWidthNbBytes = (imageInfo.ImageBMP.Width * 3) + PaddingAlignNbBytes;

            //First row in the output file.
            imageInfo.ImageBMP.AddrStartLastRow = imageInfo.ImageBMP.OffsetPixelArray + (ImageWidthNbBytes * (imageInfo.ImageBMP.Heigth - 1));

            //Find the image output size without the padding at the end.
            imageInfo.ImageOutput.Size = IMG_HEADER_NB_BYTES + (imageInfo.ImageOutput.Width * imageInfo.ImageOutput.Height * 2);

            //Find the padding bytes. 
            imageInfo.ImageOutput.NbBytesPaddingEnd = imageInfo.ImageOutput.Size % 4;

            // If there is no padding, add 4 bytes to be conformed with the Microchip format
            if (imageInfo.ImageOutput.NbBytesPaddingEnd == 0)
            {
                imageInfo.ImageOutput.NbBytesPaddingEnd = 4;
            }

            //Update image output size.
            imageInfo.ImageOutput.Size += imageInfo.ImageOutput.NbBytesPaddingEnd;

            uint outputCnt = IX_IMG_ADDR_START_PIX;
            uint bmpCnt = 0;

            for (uint row = 0; row < imageInfo.ImageBMP.Heigth; row++)
            {
                bmpCnt = imageInfo.ImageBMP.AddrStartLastRow - (ImageWidthNbBytes * row);

                for (uint col = 0; col < imageInfo.ImageBMP.Width; col++)
                {
                    // Assign colors
                    imageInfo.PixelRGB888.Blue = (byte)(imageInfo.ByteArrayBMP[bmpCnt++]);
                    imageInfo.PixelRGB888.Green = (byte)(imageInfo.ByteArrayBMP[bmpCnt++]);
                    imageInfo.PixelRGB888.Red = (byte)(imageInfo.ByteArrayBMP[bmpCnt++]);

                    // Convert from RGB888 to RGB565
                    imageInfo.PixelRGB565 = convertRGB565(imageInfo.PixelRGB888);

                    // Assign byte array
                    imageInfo.ByteArrayOutput[outputCnt++] = imageInfo.PixelRGB565.Lsb;
                    imageInfo.ByteArrayOutput[outputCnt++] = imageInfo.PixelRGB565.Msb;
                }
            }

            // Add byte padding
            for (uint i = 0; i < imageInfo.ImageOutput.NbBytesPaddingEnd; i++)
            {
                imageInfo.ByteArrayOutput[outputCnt++] = 0x00;
            }
        }

        /// <summary>
        /// Convert a 24-bit image to a 16-bit
        /// <param name="RGB_888">The 24-bit image</param>
        /// <returns>The image converted to 16-bit</returns>
        /// </summary>
        public static PixRGB565 convertRGB565(PixRGB888 RGB_888)
        {
            //Compress from 24bits to RGB565 (16bits)
            RGB_888.Red >>= 3;
            RGB_888.Green >>= 2;
            RGB_888.Blue >>= 3;

            // Construct the RGB565 pixel
            PixRGB565 RGB_565;
            int PixRGB565 = (RGB_888.Red << 11) + (RGB_888.Green << 5) + RGB_888.Blue;
            RGB_565.Lsb = (byte)(PixRGB565 & 0x000000FF);
            RGB_565.Msb = (byte)((PixRGB565 >> 8) & 0x000000FF);

            return (RGB_565);
        }

        /// <summary>
        /// Validate the image color depth and dimension.
        /// <param name="imageInfo">Image information to be converted in binary file</param>
        /// <param name="ImaBMP">Image properties</param>
        /// </summary>
        private static void ValidateImageProperties(ref ImageInfo imageInfo)
        {
            if ((imageInfo.ImageOutput.ColorDepth != 24) ||
                (imageInfo.ImageBMP.Width != 240) ||
                (imageInfo.ImageBMP.Heigth != 320) ||
                (imageInfo.ImageBMP.OffsetPixelArray != 0x36))
            {
                if (imageInfo.ImageBMP.ColorDepth != 24)
                {
                    imageInfo.FileFormat = GlobalError.FILE_COLOR_DEPTH_ERROR;
                    imageInfo.FileFormatError.ColorDepth = true;
                }

                if ((imageInfo.ImageBMP.Width != 240) || (imageInfo.ImageBMP.Heigth != 320))
                {
                    imageInfo.FileFormat = GlobalError.FILE_IMA_SIZE_ERROR;
                    imageInfo.FileFormatError.ImageSize = true;
                }

                if (imageInfo.ImageBMP.OffsetPixelArray != 0x36)
                {
                    imageInfo.FileFormat = GlobalError.FILE_OFFSET_PIX_ARRAY_ERROR;
                    imageInfo.FileFormatError.OffsetPixelArray = true;
                }
            }
        }

        /// <summary>
        /// Construct the error massage.
        /// <param name="imageInfo">Image information to be converted in binary file</param>
        /// </summary>
        private static void ConstructErrorMessage(ref ImageInfo imageInfo)
        {
            imageInfo.Message = "Error :";

            // Dimension of the image is not correct
            if (imageInfo.FileFormatError.ImageSize)
                imageInfo.Message += " Image Size is not 240 x 320 pixels";

            if (imageInfo.FileFormatError.ImageSize && imageInfo.FileFormatError.ColorDepth)
                imageInfo.Message += " and";

            // Color depth of the image is not correct
            if (imageInfo.FileFormatError.ColorDepth)
                imageInfo.Message += " Color Depth is not 24bits";

            // Problem during the conversion
            if (!imageInfo.FileFormatError.ImageSize && !imageInfo.FileFormatError.ColorDepth)
                imageInfo.Message += " Could not convert the image";
        }
    }

    #region Define classes

    /// <summary>
    /// Class to define the image parameters for the binary conversion.
    /// </summary>
    public class ImageInfo
    {
        public string PathParent;
        public string InputFileName;
        public string FolderOutputPath = "";
        public string Message = "";
        public byte FileFormat = GlobalError.FILE_NOT_OPEN_ERROR;
        public byte[] ByteArrayBMP;
        public byte[] ByteArrayOutput;
        public ImageBMPStruct ImageBMP;
        public ImageOutputStruct ImageOutput;
        public FileFormatErrorStruct FileFormatError;
        public PixRGB888 PixelRGB888;
        public PixRGB565 PixelRGB565;
    }

    /// <summary>
    /// Class to define error codes.
    /// </summary>
    public class GlobalError
    {
        public const byte FILE_NO_ERROR = 0x00;
        public const byte FILE_NOT_OPEN_ERROR = 0x01;
        public const byte FILE_COLOR_DEPTH_ERROR = 0x02;
        public const byte FILE_IMA_SIZE_ERROR = 0x03;
        public const byte FILE_OFFSET_PIX_ARRAY_ERROR = 0x04;
    }

    #endregion

    #region Define structures

    /// <summary>
    /// Structure to define the error file format of the image.
    /// </summary>
    public struct FileFormatErrorStruct
    {
        public bool NotOpen;
        public bool ColorDepth;
        public bool ImageSize;
        public bool OffsetPixelArray;
    }

    /// <summary>
    /// Structure of the 24-bit RGB image.
    /// </summary>
    public struct PixRGB888
    {
        public byte Red;
        public byte Green;
        public byte Blue;
    }

    /// <summary>
    /// Structure of the 16-bit RGB image.
    /// </summary>
    public struct PixRGB565
    {
        public byte Lsb;
        public byte Msb;
    }

    /// <summary>
    /// Structure of the image to convert.
    /// </summary>
    public struct ImageBMPStruct
    {
        public uint Size;
        public uint OffsetPixelArray;
        public uint SizeDbid;
        public uint Width;
        public uint Heigth;
        public uint ColorDepth;
        public uint Compression;
        public uint SizeRawData;
        public uint AddrStartLastRow;
    }

    /// <summary>
    /// Structure for the output image.
    /// </summary>
    public struct ImageOutputStruct
    {
        public uint Compression;
        public uint ColorDepth;
        public uint Height;
        public uint Width;
        public uint Size;
        public uint NbBytesPaddingEnd;
    }

    #endregion
}
