﻿using System.Windows.Forms;
using System.Drawing;

namespace Uploader8000
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.plateformBox = new System.Windows.Forms.GroupBox();
            this.formContainer = new Microsoft.VisualBasic.PowerPacks.ShapeContainer();
            this.lineShape5 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape4 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape1 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape2 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.ddlPort = new System.Windows.Forms.ComboBox();
            this.cbStandBy = new System.Windows.Forms.CheckBox();
            this.cbLuaScript = new System.Windows.Forms.CheckBox();
            this.tbStandby = new System.Windows.Forms.TextBox();
            this.tbLuaScript = new System.Windows.Forms.TextBox();
            this.panelUserFile = new System.Windows.Forms.Panel();
            this.imgSearchLuaScriptSE = new System.Windows.Forms.PictureBox();
            this.imgSearchStandbyImageSE = new System.Windows.Forms.PictureBox();
            this.btSearchLuaScript = new System.Windows.Forms.Button();
            this.labelUserFile = new System.Windows.Forms.Label();
            this.btSearchStandbyImage = new System.Windows.Forms.Button();
            this.panelSetup = new System.Windows.Forms.Panel();
            this.labelSetup = new System.Windows.Forms.Label();
            this.panelPlatform = new System.Windows.Forms.Panel();
            this.panelFriendlyStatus = new System.Windows.Forms.Panel();
            this.labelFriendlyStatus = new System.Windows.Forms.Label();
            this.imgFriendlyStatus = new System.Windows.Forms.PictureBox();
            this.imgLogoVT = new System.Windows.Forms.PictureBox();
            this.ddlLanguage = new System.Windows.Forms.ComboBox();
            this.imgLogoSE = new System.Windows.Forms.PictureBox();
            this.labelPlatform = new System.Windows.Forms.Label();
            this.panelAdvancedMode = new System.Windows.Forms.Panel();
            this.cbAdvancedMode = new System.Windows.Forms.CheckBox();
            this.panelHardwarePlatform = new System.Windows.Forms.Panel();
            this.labelNoModel = new System.Windows.Forms.Label();
            this.labelNoPlatform = new System.Windows.Forms.Label();
            this.labelModel = new System.Windows.Forms.Label();
            this.panelHiddenMode = new System.Windows.Forms.Panel();
            this.rtbDisplay = new System.Windows.Forms.RichTextBox();
            this.cbBootloader = new System.Windows.Forms.CheckBox();
            this.ddlAdvanceMode = new System.Windows.Forms.ComboBox();
            this.cbFontsLibrary = new System.Windows.Forms.CheckBox();
            this.cbFirmware = new System.Windows.Forms.CheckBox();
            this.btExport = new System.Windows.Forms.Button();
            this.panelExport = new System.Windows.Forms.Panel();
            this.imgHelpExportSE = new System.Windows.Forms.PictureBox();
            this.ddlLog = new System.Windows.Forms.ComboBox();
            this.imgHelpExportVT = new System.Windows.Forms.PictureBox();
            this.panelUserFile.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.imgSearchLuaScriptSE)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imgSearchStandbyImageSE)).BeginInit();
            this.panelSetup.SuspendLayout();
            this.panelPlatform.SuspendLayout();
            this.panelFriendlyStatus.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.imgFriendlyStatus)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imgLogoVT)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imgLogoSE)).BeginInit();
            this.panelAdvancedMode.SuspendLayout();
            this.panelHardwarePlatform.SuspendLayout();
            this.panelHiddenMode.SuspendLayout();
            this.panelExport.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.imgHelpExportSE)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imgHelpExportVT)).BeginInit();
            this.SuspendLayout();
            // 
            // plateformBox
            // 
            this.plateformBox.Location = new System.Drawing.Point(-13, 0);
            this.plateformBox.Name = "plateformBox";
            this.plateformBox.Size = new System.Drawing.Size(200, 100);
            this.plateformBox.TabIndex = 0;
            this.plateformBox.TabStop = false;
            // 
            // formContainer
            // 
            this.formContainer.Location = new System.Drawing.Point(0, 0);
            this.formContainer.Margin = new System.Windows.Forms.Padding(0);
            this.formContainer.Name = "formContainer";
            this.formContainer.Shapes.AddRange(new Microsoft.VisualBasic.PowerPacks.Shape[] {
            this.lineShape5,
            this.lineShape4,
            this.lineShape1,
            this.lineShape2});
            this.formContainer.Size = new System.Drawing.Size(890, 488);
            this.formContainer.TabIndex = 28;
            this.formContainer.TabStop = false;
            // 
            // lineShape5
            // 
            this.lineShape5.BorderColor = System.Drawing.SystemColors.ButtonShadow;
            this.lineShape5.Name = "lineShape5";
            this.lineShape5.X1 = 0;
            this.lineShape5.X2 = 895;
            this.lineShape5.Y1 = 510;
            this.lineShape5.Y2 = 510;
            // 
            // lineShape4
            // 
            this.lineShape4.BorderColor = System.Drawing.SystemColors.ButtonShadow;
            this.lineShape4.Name = "lineShape4";
            this.lineShape4.X1 = 0;
            this.lineShape4.X2 = 895;
            this.lineShape4.Y1 = 325;
            this.lineShape4.Y2 = 325;
            // 
            // lineShape1
            // 
            this.lineShape1.BorderColor = System.Drawing.SystemColors.ButtonShadow;
            this.lineShape1.Name = "lineShape1";
            this.lineShape1.X1 = 0;
            this.lineShape1.X2 = 895;
            this.lineShape1.Y1 = 171;
            this.lineShape1.Y2 = 171;
            // 
            // lineShape2
            // 
            this.lineShape2.BorderColor = System.Drawing.SystemColors.ButtonShadow;
            this.lineShape2.Name = "lineShape2";
            this.lineShape2.X1 = 0;
            this.lineShape2.X2 = 895;
            this.lineShape2.Y1 = 97;
            this.lineShape2.Y2 = 97;
            // 
            // ddlPort
            // 
            this.ddlPort.BackColor = System.Drawing.SystemColors.Control;
            this.ddlPort.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ddlPort.FormattingEnabled = true;
            this.ddlPort.Location = new System.Drawing.Point(218, 14);
            this.ddlPort.Margin = new System.Windows.Forms.Padding(4);
            this.ddlPort.Name = "ddlPort";
            this.ddlPort.Size = new System.Drawing.Size(653, 28);
            this.ddlPort.TabIndex = 31;
            this.ddlPort.SelectionChangeCommitted += new System.EventHandler(this.ddlPort_SelectionChangeCommitted);
            // 
            // cbStandBy
            // 
            this.cbStandBy.Location = new System.Drawing.Point(8, 41);
            this.cbStandBy.Margin = new System.Windows.Forms.Padding(4);
            this.cbStandBy.Name = "cbStandBy";
            this.cbStandBy.Size = new System.Drawing.Size(200, 40);
            this.cbStandBy.TabIndex = 33;
            this.cbStandBy.Text = "Standby image";
            this.cbStandBy.UseVisualStyleBackColor = true;
            // 
            // cbLuaScript
            // 
            this.cbLuaScript.Location = new System.Drawing.Point(8, 84);
            this.cbLuaScript.Margin = new System.Windows.Forms.Padding(4);
            this.cbLuaScript.Name = "cbLuaScript";
            this.cbLuaScript.Size = new System.Drawing.Size(200, 40);
            this.cbLuaScript.TabIndex = 34;
            this.cbLuaScript.Text = "Lua script";
            this.cbLuaScript.UseVisualStyleBackColor = true;
            // 
            // tbStandby
            // 
            this.tbStandby.Location = new System.Drawing.Point(218, 47);
            this.tbStandby.Margin = new System.Windows.Forms.Padding(5);
            this.tbStandby.Name = "tbStandby";
            this.tbStandby.ReadOnly = true;
            this.tbStandby.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tbStandby.Size = new System.Drawing.Size(576, 26);
            this.tbStandby.TabIndex = 35;
            this.tbStandby.TextChanged += new System.EventHandler(this.tbStandby_TextChanged);
            // 
            // tbLuaScript
            // 
            this.tbLuaScript.Location = new System.Drawing.Point(218, 89);
            this.tbLuaScript.Margin = new System.Windows.Forms.Padding(5);
            this.tbLuaScript.Name = "tbLuaScript";
            this.tbLuaScript.ReadOnly = true;
            this.tbLuaScript.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tbLuaScript.Size = new System.Drawing.Size(576, 26);
            this.tbLuaScript.TabIndex = 36;
            this.tbLuaScript.TextChanged += new System.EventHandler(this.tbLuaScript_TextChanged);
            // 
            // panelUserFile
            // 
            this.panelUserFile.Controls.Add(this.imgSearchLuaScriptSE);
            this.panelUserFile.Controls.Add(this.imgSearchStandbyImageSE);
            this.panelUserFile.Controls.Add(this.btSearchLuaScript);
            this.panelUserFile.Controls.Add(this.labelUserFile);
            this.panelUserFile.Controls.Add(this.btSearchStandbyImage);
            this.panelUserFile.Controls.Add(this.cbStandBy);
            this.panelUserFile.Controls.Add(this.tbLuaScript);
            this.panelUserFile.Controls.Add(this.tbStandby);
            this.panelUserFile.Controls.Add(this.cbLuaScript);
            this.panelUserFile.Location = new System.Drawing.Point(5, 183);
            this.panelUserFile.Margin = new System.Windows.Forms.Padding(4);
            this.panelUserFile.Name = "panelUserFile";
            this.panelUserFile.Size = new System.Drawing.Size(881, 130);
            this.panelUserFile.TabIndex = 38;
            // 
            // imgSearchLuaScriptSE
            // 
            this.imgSearchLuaScriptSE.Image = global::Uploader8000.Properties.Resources.Folder_with_arrow;
            this.imgSearchLuaScriptSE.Location = new System.Drawing.Point(807, 85);
            this.imgSearchLuaScriptSE.Name = "imgSearchLuaScriptSE";
            this.imgSearchLuaScriptSE.Size = new System.Drawing.Size(32, 32);
            this.imgSearchLuaScriptSE.TabIndex = 45;
            this.imgSearchLuaScriptSE.TabStop = false;
            this.imgSearchLuaScriptSE.Visible = false;
            this.imgSearchLuaScriptSE.Click += new System.EventHandler(this.imgSearchLuaScript_Click);
            // 
            // imgSearchStandbyImageSE
            // 
            this.imgSearchStandbyImageSE.Image = global::Uploader8000.Properties.Resources.Folder_with_arrow;
            this.imgSearchStandbyImageSE.Location = new System.Drawing.Point(807, 43);
            this.imgSearchStandbyImageSE.Name = "imgSearchStandbyImageSE";
            this.imgSearchStandbyImageSE.Size = new System.Drawing.Size(32, 32);
            this.imgSearchStandbyImageSE.TabIndex = 44;
            this.imgSearchStandbyImageSE.TabStop = false;
            this.imgSearchStandbyImageSE.Visible = false;
            this.imgSearchStandbyImageSE.Click += new System.EventHandler(this.imgSearchStandbyImage_Click);
            // 
            // btSearchLuaScript
            // 
            this.btSearchLuaScript.Location = new System.Drawing.Point(803, 85);
            this.btSearchLuaScript.Margin = new System.Windows.Forms.Padding(4);
            this.btSearchLuaScript.Name = "btSearchLuaScript";
            this.btSearchLuaScript.Size = new System.Drawing.Size(38, 31);
            this.btSearchLuaScript.TabIndex = 43;
            this.btSearchLuaScript.Text = "...";
            this.btSearchLuaScript.UseVisualStyleBackColor = true;
            this.btSearchLuaScript.Click += new System.EventHandler(this.btSearchLuaScript_Click);
            // 
            // labelUserFile
            // 
            this.labelUserFile.AutoSize = true;
            this.labelUserFile.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.labelUserFile.Location = new System.Drawing.Point(4, 12);
            this.labelUserFile.Name = "labelUserFile";
            this.labelUserFile.Size = new System.Drawing.Size(85, 20);
            this.labelUserFile.TabIndex = 33;
            this.labelUserFile.Text = "User files";
            // 
            // btSearchStandbyImage
            // 
            this.btSearchStandbyImage.Location = new System.Drawing.Point(803, 42);
            this.btSearchStandbyImage.Margin = new System.Windows.Forms.Padding(4);
            this.btSearchStandbyImage.Name = "btSearchStandbyImage";
            this.btSearchStandbyImage.Size = new System.Drawing.Size(38, 31);
            this.btSearchStandbyImage.TabIndex = 42;
            this.btSearchStandbyImage.Text = "...";
            this.btSearchStandbyImage.UseVisualStyleBackColor = true;
            this.btSearchStandbyImage.Click += new System.EventHandler(this.btSearchStandbyImage_Click);
            // 
            // panelSetup
            // 
            this.panelSetup.Controls.Add(this.labelSetup);
            this.panelSetup.Controls.Add(this.ddlPort);
            this.panelSetup.Location = new System.Drawing.Point(5, 107);
            this.panelSetup.Margin = new System.Windows.Forms.Padding(4);
            this.panelSetup.Name = "panelSetup";
            this.panelSetup.Size = new System.Drawing.Size(881, 53);
            this.panelSetup.TabIndex = 39;
            // 
            // labelSetup
            // 
            this.labelSetup.AutoSize = true;
            this.labelSetup.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.labelSetup.Location = new System.Drawing.Point(5, 17);
            this.labelSetup.Name = "labelSetup";
            this.labelSetup.Size = new System.Drawing.Size(57, 20);
            this.labelSetup.TabIndex = 32;
            this.labelSetup.Text = "Setup";
            // 
            // panelPlatform
            // 
            this.panelPlatform.Controls.Add(this.panelFriendlyStatus);
            this.panelPlatform.Controls.Add(this.imgLogoVT);
            this.panelPlatform.Controls.Add(this.ddlLanguage);
            this.panelPlatform.Controls.Add(this.imgLogoSE);
            this.panelPlatform.Location = new System.Drawing.Point(5, 7);
            this.panelPlatform.Margin = new System.Windows.Forms.Padding(4);
            this.panelPlatform.Name = "panelPlatform";
            this.panelPlatform.Size = new System.Drawing.Size(881, 81);
            this.panelPlatform.TabIndex = 40;
            // 
            // panelFriendlyStatus
            // 
            this.panelFriendlyStatus.Controls.Add(this.labelFriendlyStatus);
            this.panelFriendlyStatus.Controls.Add(this.imgFriendlyStatus);
            this.panelFriendlyStatus.Location = new System.Drawing.Point(483, 10);
            this.panelFriendlyStatus.Name = "panelFriendlyStatus";
            this.panelFriendlyStatus.Size = new System.Drawing.Size(391, 60);
            this.panelFriendlyStatus.TabIndex = 31;
            // 
            // labelFriendlyStatus
            // 
            this.labelFriendlyStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold);
            this.labelFriendlyStatus.Location = new System.Drawing.Point(3, 2);
            this.labelFriendlyStatus.Name = "labelFriendlyStatus";
            this.labelFriendlyStatus.Size = new System.Drawing.Size(322, 55);
            this.labelFriendlyStatus.TabIndex = 1;
            this.labelFriendlyStatus.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // imgFriendlyStatus
            // 
            this.imgFriendlyStatus.Location = new System.Drawing.Point(331, 2);
            this.imgFriendlyStatus.Name = "imgFriendlyStatus";
            this.imgFriendlyStatus.Size = new System.Drawing.Size(55, 55);
            this.imgFriendlyStatus.TabIndex = 0;
            this.imgFriendlyStatus.TabStop = false;
            // 
            // imgLogoVT
            // 
            this.imgLogoVT.Image = global::Uploader8000.Properties.Resources.VT_logo;
            this.imgLogoVT.Location = new System.Drawing.Point(9, 8);
            this.imgLogoVT.Name = "imgLogoVT";
            this.imgLogoVT.Size = new System.Drawing.Size(64, 64);
            this.imgLogoVT.TabIndex = 30;
            this.imgLogoVT.TabStop = false;
            // 
            // ddlLanguage
            // 
            this.ddlLanguage.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ddlLanguage.FormattingEnabled = true;
            this.ddlLanguage.Location = new System.Drawing.Point(218, 27);
            this.ddlLanguage.Name = "ddlLanguage";
            this.ddlLanguage.Size = new System.Drawing.Size(242, 28);
            this.ddlLanguage.TabIndex = 28;
            this.ddlLanguage.Visible = false;
            this.ddlLanguage.SelectedIndexChanged += new System.EventHandler(this.cbLanguage_SelectedIndexChanged);
            // 
            // imgLogoSE
            // 
            this.imgLogoSE.Image = ((System.Drawing.Image)(resources.GetObject("imgLogoSE.Image")));
            this.imgLogoSE.Location = new System.Drawing.Point(8, 10);
            this.imgLogoSE.Margin = new System.Windows.Forms.Padding(5);
            this.imgLogoSE.Name = "imgLogoSE";
            this.imgLogoSE.Size = new System.Drawing.Size(180, 60);
            this.imgLogoSE.TabIndex = 27;
            this.imgLogoSE.TabStop = false;
            this.imgLogoSE.Visible = false;
            // 
            // labelPlatform
            // 
            this.labelPlatform.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.labelPlatform.Location = new System.Drawing.Point(274, 3);
            this.labelPlatform.Name = "labelPlatform";
            this.labelPlatform.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.labelPlatform.Size = new System.Drawing.Size(213, 42);
            this.labelPlatform.TabIndex = 29;
            this.labelPlatform.Text = "Hardware platform";
            this.labelPlatform.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panelAdvancedMode
            // 
            this.panelAdvancedMode.Controls.Add(this.cbAdvancedMode);
            this.panelAdvancedMode.Controls.Add(this.panelHardwarePlatform);
            this.panelAdvancedMode.Location = new System.Drawing.Point(5, 328);
            this.panelAdvancedMode.Margin = new System.Windows.Forms.Padding(4);
            this.panelAdvancedMode.Name = "panelAdvancedMode";
            this.panelAdvancedMode.Size = new System.Drawing.Size(881, 52);
            this.panelAdvancedMode.TabIndex = 42;
            // 
            // cbAdvancedMode
            // 
            this.cbAdvancedMode.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.cbAdvancedMode.Location = new System.Drawing.Point(8, 8);
            this.cbAdvancedMode.Margin = new System.Windows.Forms.Padding(4);
            this.cbAdvancedMode.Name = "cbAdvancedMode";
            this.cbAdvancedMode.Size = new System.Drawing.Size(200, 40);
            this.cbAdvancedMode.TabIndex = 0;
            this.cbAdvancedMode.Text = "Advanced Mode";
            this.cbAdvancedMode.UseVisualStyleBackColor = true;
            this.cbAdvancedMode.CheckedChanged += new System.EventHandler(this.cbAdvancedMode_CheckedChanged);
            // 
            // panelHardwarePlatform
            // 
            this.panelHardwarePlatform.Controls.Add(this.labelNoModel);
            this.panelHardwarePlatform.Controls.Add(this.labelNoPlatform);
            this.panelHardwarePlatform.Controls.Add(this.labelModel);
            this.panelHardwarePlatform.Controls.Add(this.labelPlatform);
            this.panelHardwarePlatform.Location = new System.Drawing.Point(218, 3);
            this.panelHardwarePlatform.Name = "panelHardwarePlatform";
            this.panelHardwarePlatform.Size = new System.Drawing.Size(614, 48);
            this.panelHardwarePlatform.TabIndex = 3;
            // 
            // labelNoModel
            // 
            this.labelNoModel.Location = new System.Drawing.Point(154, 3);
            this.labelNoModel.Name = "labelNoModel";
            this.labelNoModel.Size = new System.Drawing.Size(114, 42);
            this.labelNoModel.TabIndex = 30;
            this.labelNoModel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // labelNoPlatform
            // 
            this.labelNoPlatform.Location = new System.Drawing.Point(488, 3);
            this.labelNoPlatform.Name = "labelNoPlatform";
            this.labelNoPlatform.Size = new System.Drawing.Size(123, 42);
            this.labelNoPlatform.TabIndex = 30;
            this.labelNoPlatform.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.labelNoPlatform.TextChanged += new System.EventHandler(this.labelNoPlatform_TextChanged);
            // 
            // labelModel
            // 
            this.labelModel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.labelModel.Location = new System.Drawing.Point(3, 3);
            this.labelModel.Name = "labelModel";
            this.labelModel.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.labelModel.Size = new System.Drawing.Size(145, 42);
            this.labelModel.TabIndex = 29;
            this.labelModel.Text = "Actual model";
            this.labelModel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panelHiddenMode
            // 
            this.panelHiddenMode.Controls.Add(this.rtbDisplay);
            this.panelHiddenMode.Controls.Add(this.cbBootloader);
            this.panelHiddenMode.Controls.Add(this.ddlAdvanceMode);
            this.panelHiddenMode.Controls.Add(this.cbFontsLibrary);
            this.panelHiddenMode.Controls.Add(this.cbFirmware);
            this.panelHiddenMode.Location = new System.Drawing.Point(5, 387);
            this.panelHiddenMode.Margin = new System.Windows.Forms.Padding(4);
            this.panelHiddenMode.Name = "panelHiddenMode";
            this.panelHiddenMode.Size = new System.Drawing.Size(881, 111);
            this.panelHiddenMode.TabIndex = 43;
            this.panelHiddenMode.Visible = false;
            // 
            // rtbDisplay
            // 
            this.rtbDisplay.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.rtbDisplay.Location = new System.Drawing.Point(218, 48);
            this.rtbDisplay.Name = "rtbDisplay";
            this.rtbDisplay.Size = new System.Drawing.Size(621, 56);
            this.rtbDisplay.TabIndex = 42;
            this.rtbDisplay.Text = "";
            this.rtbDisplay.Visible = false;
            this.rtbDisplay.TextChanged += new System.EventHandler(this.rtbDisplay_TextChanged);
            // 
            // cbBootloader
            // 
            this.cbBootloader.Location = new System.Drawing.Point(8, 80);
            this.cbBootloader.Margin = new System.Windows.Forms.Padding(4);
            this.cbBootloader.Name = "cbBootloader";
            this.cbBootloader.Size = new System.Drawing.Size(200, 30);
            this.cbBootloader.TabIndex = 36;
            this.cbBootloader.Text = "Boot loader";
            this.cbBootloader.UseVisualStyleBackColor = true;
            // 
            // ddlAdvanceMode
            // 
            this.ddlAdvanceMode.BackColor = System.Drawing.SystemColors.Control;
            this.ddlAdvanceMode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ddlAdvanceMode.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.ddlAdvanceMode.FormattingEnabled = true;
            this.ddlAdvanceMode.Location = new System.Drawing.Point(218, 13);
            this.ddlAdvanceMode.Margin = new System.Windows.Forms.Padding(4);
            this.ddlAdvanceMode.Name = "ddlAdvanceMode";
            this.ddlAdvanceMode.Size = new System.Drawing.Size(621, 28);
            this.ddlAdvanceMode.TabIndex = 32;
            // 
            // cbFontsLibrary
            // 
            this.cbFontsLibrary.Location = new System.Drawing.Point(8, 48);
            this.cbFontsLibrary.Margin = new System.Windows.Forms.Padding(4);
            this.cbFontsLibrary.Name = "cbFontsLibrary";
            this.cbFontsLibrary.Size = new System.Drawing.Size(200, 30);
            this.cbFontsLibrary.TabIndex = 35;
            this.cbFontsLibrary.Text = "Fonts library";
            this.cbFontsLibrary.UseVisualStyleBackColor = true;
            // 
            // cbFirmware
            // 
            this.cbFirmware.Location = new System.Drawing.Point(8, 15);
            this.cbFirmware.Margin = new System.Windows.Forms.Padding(4);
            this.cbFirmware.Name = "cbFirmware";
            this.cbFirmware.Size = new System.Drawing.Size(200, 30);
            this.cbFirmware.TabIndex = 34;
            this.cbFirmware.Text = "Firmware";
            this.cbFirmware.UseVisualStyleBackColor = true;
            // 
            // btExport
            // 
            this.btExport.Location = new System.Drawing.Point(8, 12);
            this.btExport.Margin = new System.Windows.Forms.Padding(4);
            this.btExport.Name = "btExport";
            this.btExport.Size = new System.Drawing.Size(192, 52);
            this.btExport.TabIndex = 44;
            this.btExport.Text = "EXPORT";
            this.btExport.UseVisualStyleBackColor = true;
            this.btExport.Click += new System.EventHandler(this.btExport_Click);
            // 
            // panelExport
            // 
            this.panelExport.Controls.Add(this.imgHelpExportSE);
            this.panelExport.Controls.Add(this.ddlLog);
            this.panelExport.Controls.Add(this.imgHelpExportVT);
            this.panelExport.Controls.Add(this.btExport);
            this.panelExport.Location = new System.Drawing.Point(5, 525);
            this.panelExport.Margin = new System.Windows.Forms.Padding(4);
            this.panelExport.Name = "panelExport";
            this.panelExport.Size = new System.Drawing.Size(881, 76);
            this.panelExport.TabIndex = 46;
            // 
            // imgHelpExportSE
            // 
            this.imgHelpExportSE.Image = ((System.Drawing.Image)(resources.GetObject("imgHelpExportSE.Image")));
            this.imgHelpExportSE.Location = new System.Drawing.Point(849, 22);
            this.imgHelpExportSE.Margin = new System.Windows.Forms.Padding(4);
            this.imgHelpExportSE.Name = "imgHelpExportSE";
            this.imgHelpExportSE.Size = new System.Drawing.Size(22, 32);
            this.imgHelpExportSE.TabIndex = 50;
            this.imgHelpExportSE.TabStop = false;
            this.imgHelpExportSE.Visible = false;
            this.imgHelpExportSE.Click += new System.EventHandler(this.imgHelpExportSE_Click);
            // 
            // ddlLog
            // 
            this.ddlLog.BackColor = System.Drawing.SystemColors.Control;
            this.ddlLog.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ddlLog.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.ddlLog.FormattingEnabled = true;
            this.ddlLog.Location = new System.Drawing.Point(218, 25);
            this.ddlLog.Margin = new System.Windows.Forms.Padding(4);
            this.ddlLog.Name = "ddlLog";
            this.ddlLog.Size = new System.Drawing.Size(621, 28);
            this.ddlLog.TabIndex = 42;
            // 
            // imgHelpExportVT
            // 
            this.imgHelpExportVT.Image = ((System.Drawing.Image)(resources.GetObject("imgHelpExportVT.Image")));
            this.imgHelpExportVT.Location = new System.Drawing.Point(849, 22);
            this.imgHelpExportVT.Margin = new System.Windows.Forms.Padding(4);
            this.imgHelpExportVT.Name = "imgHelpExportVT";
            this.imgHelpExportVT.Size = new System.Drawing.Size(22, 32);
            this.imgHelpExportVT.TabIndex = 49;
            this.imgHelpExportVT.TabStop = false;
            this.imgHelpExportVT.Click += new System.EventHandler(this.imgHelpExportVT_Click);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(890, 488);
            this.Controls.Add(this.panelPlatform);
            this.Controls.Add(this.panelExport);
            this.Controls.Add(this.panelHiddenMode);
            this.Controls.Add(this.panelAdvancedMode);
            this.Controls.Add(this.panelSetup);
            this.Controls.Add(this.panelUserFile);
            this.Controls.Add(this.formContainer);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Margin = new System.Windows.Forms.Padding(5);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(900, 650);
            this.MinimumSize = new System.Drawing.Size(900, 520);
            this.Name = "frmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.panelUserFile.ResumeLayout(false);
            this.panelUserFile.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.imgSearchLuaScriptSE)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imgSearchStandbyImageSE)).EndInit();
            this.panelSetup.ResumeLayout(false);
            this.panelSetup.PerformLayout();
            this.panelPlatform.ResumeLayout(false);
            this.panelFriendlyStatus.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.imgFriendlyStatus)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imgLogoVT)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imgLogoSE)).EndInit();
            this.panelAdvancedMode.ResumeLayout(false);
            this.panelHardwarePlatform.ResumeLayout(false);
            this.panelHiddenMode.ResumeLayout(false);
            this.panelExport.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.imgHelpExportSE)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imgHelpExportVT)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox plateformBox;
        private System.Windows.Forms.PictureBox imgLogoSE;
        private Microsoft.VisualBasic.PowerPacks.ShapeContainer formContainer;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape2;
        private System.Windows.Forms.ComboBox ddlPort;
        private System.Windows.Forms.CheckBox cbStandBy;
        private System.Windows.Forms.CheckBox cbLuaScript;
        private System.Windows.Forms.TextBox tbStandby;
        private System.Windows.Forms.TextBox tbLuaScript;
        private System.Windows.Forms.Panel panelUserFile;
        private System.Windows.Forms.Panel panelSetup;
        private System.Windows.Forms.Panel panelPlatform;
        private System.Windows.Forms.Panel panelAdvancedMode;
        private System.Windows.Forms.Panel panelHiddenMode;
        private System.Windows.Forms.CheckBox cbFontsLibrary;
        private System.Windows.Forms.CheckBox cbFirmware;
        private System.Windows.Forms.CheckBox cbBootloader;
        private System.Windows.Forms.ComboBox ddlAdvanceMode;
        private System.Windows.Forms.Button btExport;
        private System.Windows.Forms.Panel panelExport;
        private System.Windows.Forms.CheckBox cbAdvancedMode;
        private System.Windows.Forms.Button btSearchStandbyImage;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape5;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape4;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape1;
        private System.Windows.Forms.Button btSearchLuaScript;
        private System.Windows.Forms.Label labelUserFile;
        private System.Windows.Forms.Label labelSetup;
        private System.Windows.Forms.ComboBox ddlLanguage;
        private System.Windows.Forms.Label labelPlatform;
        private PictureBox imgHelpExportVT;
        private ComboBox ddlLog;
        private RichTextBox rtbDisplay;
        private PictureBox imgSearchLuaScriptSE;
        private PictureBox imgSearchStandbyImageSE;
        private PictureBox imgHelpExportSE;
        private PictureBox imgLogoVT;
        private Panel panelHardwarePlatform;
        private Label labelNoPlatform;
        private Panel panelFriendlyStatus;
        private PictureBox imgFriendlyStatus;
        private Label labelFriendlyStatus;
        private Label labelNoModel;
        private Label labelModel;
    }
}

