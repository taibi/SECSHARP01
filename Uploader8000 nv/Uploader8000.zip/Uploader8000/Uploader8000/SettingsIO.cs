﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.IO;
using System.Xml.Linq;
using System.Xml.XPath;

namespace Uploader8000
{
    public class SettingsIO
    {
        public bool Import(frmMain m_parent, string settingsFilePath)
        {
            bool result = true;

            if (!File.Exists(settingsFilePath))
            {
                result = false;
            }
            else
            {
                var appSettings = Properties.Settings.Default;
                try
                {
                    var config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.PerUserRoamingAndLocal);
                    string appSettingsXmlName = Properties.Settings.Default.Context["GroupName"].ToString();

                    // Open settings file as XML
                    var import = XDocument.Load(settingsFilePath);
                    // Get the whole XML inside the settings node
                    var settings = import.XPathSelectElements("//" + appSettingsXmlName);

                    config.GetSectionGroup("userSettings")
                        .Sections[appSettingsXmlName]
                        .SectionInformation
                        .SetRawXml(settings.Single().ToString());
                    config.Save(ConfigurationSaveMode.Modified);
                    ConfigurationManager.RefreshSection("userSettings");

                    appSettings.Reload();
                }
                catch (Exception e)
                {
                    m_parent.UpdateLogText("Error :" + e.Message);
                    result = false;
                    appSettings.Reload(); // from last set saved, not defaults
                }
            }
            return result;
        }

        public void Export(string settingsFilePath)
        {
            Properties.Settings.Default.Save();
            var config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.PerUserRoamingAndLocal);
            config.SaveAs(settingsFilePath);
        }
    }
}
