﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Management;
using System.Reflection;
using System.Resources;
using System.Threading;
using System.Windows.Forms;
using Ionic.Zip;
using System.Data;

namespace Uploader8000
{
    public partial class frmMain : Form
    {
        #region Constants

        // Application revision
        const string REVISION = "1.10";

        // File to save form parameters
        const string ConfigFileName = "config.xml";

        // Information used to extract binary from the zipped file.
        const string ZipFileName = "firm8000.fm8";
        const string ZipPassword = "pqrtup8994740578348y39gh9e88wloihfiyvisahityfinasy54i9045oiutwepiotuoerofkldjglkg"; 

        // Constants used to communicate with the device
        const string LOAD_FIRMWARE_CMD = "1";
        const string LOAD_CUSTOM_IMG_CMD = "2";
        const string LOAD_FONTS_LIB_CMD = "3";
        const string LOAD_LUA_CMD = "4";
        const string LOAD_AUTO_BOOTLOADER = "2";
        const string QUIT_CMD = "0";
        const string GO_TO_GAMMA_FROM_MINIBOOT = "0";
        const string GO_TO_AUTOBOOT_FROM_MINIBOOT = "1";

        const string RESET_CMD_LEVEL2 = "#000C0074B0FFFF28!";
        const string RESET_CMD_LEVEL1 = "#000C0076B0FFFF2A!";
        const string ID_STR_GET_CMD = "#000C0078B0FFFF2C!";

        const string MINIBOOT_MENU_RDY = "A2000";
        const string AUTOBOOT_MENU_RDY = "A2001";
        const string READY_TO_RCV_FILE = "A2002";

        const string SYNC_CMD_BOOT1 = "BOOT1_ID_STR";
        const string SYNC_CMD_BOOT2 = "BOOT2_ID_STR";
        const string SYNC_CMD_GAMMA = "GAMMA_ID_STR";

        // Command and response to recognize the device's platform
        // Command send : #000C0000207AFEF8!
        // Response : #00120001207AFE00  shall be received exactly "as is" 
        //            0002 is an hexadecimal number actually representing platform 2. 
        //            0B is the checksum (no need to verify it)
        //            ! is end of command
        const string GET_PLATFORM_ID = "#000C0000207AFEF8!";
        const string ANS_PLATFORM_P  = "#00120001207AFE00";     // 00020B!;
        const string ANS_PLATFORM_NS = "#000E0001207AFE035E!";  // 03 means unsupported register

        // Command and response to recognize the device's model
        // Command send : #000C00002012FEE3!
        // Response : #001200012012FE00009C10!
        // Note: 9C = Model "156"
        const string GET_MODEL_ID = "#000C00002012FEE3!";
        const string ANS_MODEL = "#001200012012FE00";     // 009C10!;
        
        // Codes to identify the device's model
        const int MODEL_VT8350 = 143;
        const int MODEL_VT8300 = 144;
        const int MODEL_SE8350 = 145;
        const int MODEL_SE8300 = 146;

        const int MODEL_VTR8350 = 153;
        const int MODEL_VTR8300 = 154;
        const int MODEL_SER8350 = 155;
        const int MODEL_SER8300 = 156;

        const int MODEL_VT8600 = 160;
        const int MODEL_SE8600 = 161;
        const int MODEL_VT8650 = 162;
        const int MODEL_SE8650 = 163;

        #endregion

        #region Define global classes

        CommunicationManager comm = new CommunicationManager();
        Uploader uploader = new Uploader();
        DataTable model = new DataTable();
        OpenFileDialog openFileDialogStandby = new OpenFileDialog();

        #endregion

        #region Form

        /// <summary>
        /// The main form function
        /// </summary>
        public frmMain()
        {
            AddDllToBuild();
            InitializeComponent();
            this.FormClosing += frmMain_FormClosing;
        }

        /// <summary>
        /// The load function of the form
        /// </summary>
        /// <param name="sender">The object that raised the event</param>
        /// <param name="e">Event arguments</param>
        private void frmMain_Load(object sender, EventArgs e)
        {
            InitializeStandbyImageFileDialog();

            // Create a model table to identify the device's model
            CreateModelTable();

            // Start to initialize the application
            uploader.Initializing = true;

            // According to the application variables, update the application during the build
            ChangeVersionConfiguration();

            // Resize the form because the Advance Mode is not checked
            ChangeFormSize();

            // Assign binding values to the log's drop down list
            ddlLog.DataSource = outputLog;

            // Language
            //PopulateLanguageList();
            //PopulateFieldsWithChoosenLanguage();

            // Identify the available ports (availPorts)
            IdentifyConnectedPort();

            // Use thread to update the port's drop down list
            portThread = new Thread(new ThreadStart(UpdatePortList));
            portThread.Start();
            autoResetEvent.WaitOne();

            // Assign binding values to the port's drop down list
            ddlPort.DataSource = availPorts;
            SelectPort(FindPortIndex());

            // Find the platform value if the connected port is STMicroelectronics
            var port = ddlPort.Text;
            if (isSTMicroelectronics(port))
            {
                uploader.PortUsed = port;
                GetPlatformAndModel();
            }
            else
            {
                // The application is not connected to one device
                labelNoPlatform.Text = " ";
            }

            if (comm.isPortOpen())
                comm.ClosePort();

            // The initialization is completed
            uploader.Initializing = false;
        }

        /// <summary>
        /// The closing function of the form to stop the port thread,
        /// to save user settings and remove some folders.
        /// </summary>
        /// <param name="sender">The object that raised the event</param>
        /// <param name="e">Event arguments</param>
        private void frmMain_FormClosing(Object sender, FormClosingEventArgs e)
        {
            // In case windows is trying to shut down, don't hold the process up
            // and an user closing will clear the resources
            if (e.CloseReason == CloseReason.WindowsShutDown || e.CloseReason == CloseReason.UserClosing)
            {
                // Clear resources
                if (portThread.IsAlive)
                    portThread.Abort();

                // Save parameters for further usage
                ExportSettings();

                // Remove the hidden directories
                RemoveFolders();
            }
        }

        #endregion

        #region Form events

        /// <summary>
        /// By clicking the the Start button, the uploading begins.
        /// </summary>
        /// <param name="sender">The object that raised the event</param>
        /// <param name="e">Event arguments</param>
        private void btExport_Click(object sender, EventArgs e)
        {
            ClearApplication();

            // Validate the user selections before to start the upload
            if (!ValidateSelection())
            {
                return;
            }

            // Start the the upload
            uploader.Uploading = true;
            EnablingForm(true);

            // Save parameters for further usage
            ExportSettings();

            // Result of all uploads
            if (UploadSequence())
            {
                UpdateLogText("The transfer has been completed successfully");
                SaveLogFile("Pass");
            }
            else
            {
                UpdateLogText("Error : A problem occurs during the transfer");
                SaveLogFile("Fail");
            }

            EnablingForm(false);
        }

        /// <summary>
        /// When the value of the Advance Mode checkbox changed, modify the
        /// form size and show/hide the advance choice according to the 
        /// checkbox value.
        /// </summary>
        /// <param name="sender">The object that raised the event</param>
        /// <param name="e">Event arguments</param>
        private void cbAdvancedMode_CheckedChanged(object sender, EventArgs e)
        {
            ChangeFormSize();
        }

        /// <summary>
        /// According to the language selection, all texts are changed.
        /// </summary>
        /// <param name="sender">The object that raised the event</param>
        /// <param name="e">Event arguments</param>
        private void cbLanguage_SelectedIndexChanged(object sender, EventArgs e)
        {
            PopulateFieldsWithChoosenLanguage();
        }

        /// <summary>
        /// Open a dialog box to choose a Standby Image (use by Viconics application).
        /// </summary>
        /// <param name="sender">The object that raised the event</param>
        /// <param name="e">Event arguments</param>
        private void btSearchStandbyImage_Click(object sender, EventArgs e)
        {
            SearchStandbyImage();
        }

        /// <summary>
        /// Open a dialog box to choose a Standby Image (use by Schneider application).
        /// </summary>
        /// <param name="sender">The object that raised the event</param>
        /// <param name="e">Event arguments</param>
        private void imgSearchStandbyImage_Click(object sender, EventArgs e)
        {
            SearchStandbyImage();
        }

        /// <summary>
        /// Open a dialog box to choose a Lua Script (use by Viconics application).
        /// </summary>
        /// <param name="sender">The object that raised the event</param>
        /// <param name="e">Event arguments</param>
        private void btSearchLuaScript_Click(object sender, EventArgs e)
        {
            SearchLuaScript();
        }

        /// <summary>
        /// Open a dialog box to choose a Lua Script (use by Schneider application).
        /// </summary>
        /// <param name="sender">The object that raised the event</param>
        /// <param name="e">Event arguments</param>
        private void imgSearchLuaScript_Click(object sender, EventArgs e)
        {
            SearchLuaScript();
        }

        /// <summary>
        /// Open the application PDF help file.
        /// </summary>
        /// <param name="sender">The object that raised the event</param>
        /// <param name="e">Event arguments</param>
        private void imgHelpExportVT_Click(object sender, EventArgs e)
        {
            OpenPDF("Help start upload.pdf");
        }

        /// <summary>
        /// Open the application PDF help file.
        /// </summary>
        /// <param name="sender">The object that raised the event</param>
        /// <param name="e">Event arguments</param>
        private void imgHelpExportSE_Click(object sender, EventArgs e)
        {
            OpenPDF("Help start upload.pdf");
        }

        /// <summary>
        /// When the user changes the selection, update the connected communication port
        /// information and get the platform value if the STMicroelectronics port is connected.
        /// </summary>
        /// <param name="sender">The object that raised the event</param>
        /// <param name="e">Event arguments</param>
        private void ddlPort_SelectionChangeCommitted(object sender, EventArgs e)
        {
            comm.PortName = GetCommPort();

            var port = ddlPort.Text;
            if (isSTMicroelectronics(port))
            {
                uploader.PortUsed = port;
                GetPlatformAndModel();
            }
            else
            {
                ClearAdvancedMode();

                if (uploader.PortUsed != port)
                    uploader.PortUsed = "";
            }
        }

        /// <summary>
        /// When the RichTextBox is updated, the log drop down list will be also updated.
        /// </summary>
        /// <param name="sender">The object that raised the event</param>
        /// <param name="e">Event arguments</param>
        private void rtbDisplay_TextChanged(object sender, EventArgs e)
        {
            for (var index = uploader.LastRichTextBoxLine; index < rtbDisplay.Lines.Length; index++)
            {
                UpdateLogInformation(rtbDisplay.Lines[index]);
                uploader.LastRichTextBoxLine = index;
            }
        }

        /// <summary>
        /// When the text changes, truncate the string if the number of
        /// characters exceeds the text box width.
        /// </summary>
        /// <param name="sender">The object that raised the event</param>
        /// <param name="e">Event arguments</param>
        private void tbStandby_TextChanged(object sender, EventArgs e)
        {
            tbStandby.Truncate();
        }

        /// <summary>
        /// When the text changes, truncate the string if the number of
        /// characters exceeds the text box width.
        /// </summary>
        /// <param name="sender">The object that raised the event</param>
        /// <param name="e">Event arguments</param>
        private void tbLuaScript_TextChanged(object sender, EventArgs e)
        {
            tbLuaScript.Truncate();
        }

        /// <summary>
        /// When the text changes, update the Friendly Status panel.
        /// </summary>
        /// <param name="sender">The object that raised the event</param>
        /// <param name="e">Event arguments</param>
        private void labelNoPlatform_TextChanged(object sender, EventArgs e)
        {
            if (labelNoPlatform.Text == "Unsupported")
            {
                labelFriendlyStatus.Text = "Not supported";
                imgFriendlyStatus.Image = Properties.Resources.yellow_circle;
            }
            else if (isSupportedPlatform())
            {
                labelFriendlyStatus.Text = "Ready";
                imgFriendlyStatus.Image = Properties.Resources.green_circle;
            }
            else
            {
                labelFriendlyStatus.Text = "Not connected";
                imgFriendlyStatus.Image = Properties.Resources.red_circle;
            }
        }

        #endregion

        #region Access the device

        /// <summary>
        /// Define the communication parameters and verify if the port is opened
        /// <returns>True if the port is opened otherwise false</returns>
        /// </summary>
        private bool Open()
        {
            bool bResult = false;

            try
            {
                comm.Parity = "0";
                comm.StopBits = "1";
                comm.DataBits = "8";
                comm.BaudRate = "115200";
                comm.DisplayWindow = rtbDisplay;
                ReadCommPortName();

                if (comm.PortAvailable(GetCommPort()) == true)
                {
                    if (comm.OpenPort())
                    {
                        bResult = true;
                    }
                }
            }
            catch (Exception e)
            {
                UpdateLogText("Error : " + e.Message);
            }

            return bResult;
        }

        /// <summary>
        /// Open the COM port if it is not already open, check the application
        /// identifier and verify the operation compatibility.
        /// <returns>True if all verifications are correct otherwise false</returns>
        /// </summary>
        private bool GetAppIDAndCheckCompatibility()
        {
            if (!CheckAndOpenComPort())
            {
                UpdateLogText("Error : Could not open and use the specified COM port");
                return false;
            }

            GetAppID();

            if (!CheckOperationCompatibility())
            {
                UpdateLogText("Error : Compatibility error, check your selected operations");
                return false;
            }

            return true;
        }

        /// <summary>
        /// Verify that the upload is in the right boot.
        /// <returns>True if all verifications are correct otherwise false</returns>
        /// </summary>
        private bool CheckOperationCompatibility()
        {
            bool rightBoot = true;

            if (uploader.CurrentAppID == SYNC_CMD_BOOT1)
            {
                if (cbStandBy.Checked || cbLuaScript.Checked || cbFirmware.Checked || cbFontsLibrary.Checked)
                    rightBoot = false;
            }
            else if (uploader.CurrentAppID == SYNC_CMD_BOOT2)
            {
                if (cbBootloader.Checked)
                    rightBoot = false;
            }

            return rightBoot;
        }

        /// <summary>
        /// Get the application identification
        /// </summary>
        private void GetAppID()
        {
            string app_id_str = string.Empty;

            comm.WriteData(ID_STR_GET_CMD + "\r");

            // Read the answer  
            comm.ReceiveData();
            app_id_str = comm.gInMSG;
            int retries = 100;

            while (retries > 0)
            {
                if (app_id_str.Contains(SYNC_CMD_GAMMA) || app_id_str.Contains(SYNC_CMD_BOOT1) || app_id_str.Contains(SYNC_CMD_BOOT2))
                {
                    break;
                }

                Thread.Sleep(5);
                comm.ReceiveData();
                app_id_str = comm.gInMSG;
                retries--;
            }

            if (retries <= 0)
            {
                app_id_str = string.Empty;
            }
            else
            {
                if (app_id_str.Contains(SYNC_CMD_BOOT1))
                    app_id_str = SYNC_CMD_BOOT1;
                else if (app_id_str.Contains(SYNC_CMD_BOOT2))
                    app_id_str = SYNC_CMD_BOOT2;
                else if (app_id_str.Contains(SYNC_CMD_GAMMA))
                    app_id_str = SYNC_CMD_GAMMA;
                else
                    app_id_str = string.Empty;
            }

            uploader.CurrentAppID = app_id_str;
        }

        /// <summary>
        /// Send a reset command to prepare the device to the upload and wait
        /// for the device to be ready.
        /// <param name="reset_cmd">The reset command</param>
        /// <returns>True if the operation succeed otherwise false</returns>
        /// </summary>
        private bool SendResetAndWaitDeviceReady(string reset_cmd)
        {
            const int MAX_RETRIES = 50;
            int retries = MAX_RETRIES;
            bool bResult;

            comm.WriteData(reset_cmd);

            ClosePort();
            while (comm.PortAvailable(GetCommPort()) == true)
            {
                Thread.Sleep(1);
            }

            Thread.Sleep(5000);

            while (retries > 0)
            {
                if (Open() == true)
                {
                    break;
                }
                Thread.Sleep(1);
                retries--;
            }

            bResult = (retries > 0) ? true : false;

            if (bResult)
            {
                GetAppID();
            }

            return bResult;
        }

        /// <summary>
        /// Wait for the device to be ready to continue the upload.
        /// <returns>True if the process succeed otherwise false</returns>
        /// </summary>
        private bool WaitDeviceReadyToContinue(string waitingAnswer)
        {
            const int MAX_RETRIES = 50;
            int retries = MAX_RETRIES;

            comm.ReceiveData();
            string msg = comm.gInMSG;

            while (msg.Contains(waitingAnswer) == false && retries > 0)
            {
                Thread.Sleep(5);
                comm.ReceiveData();
                msg = comm.gInMSG;

                if (waitingAnswer != READY_TO_RCV_FILE)
                    retries--;
            }

            return (retries > 0) ? true : false;
        }

        /// <summary>
        /// When th upload is completed, send a quit command to the device
        /// to return in operation mode.
        /// </summary>
        private void CloseUpload()
        {
            if (comm.isPortOpen())
            {
                comm.ClosePort();
            }
        }

        /// <summary>
        /// Send the quit command to the device to return in operation mode.
        /// <param name="command">The quit command</param>
        /// </summary>
        private void QuitCmd(string command)
        {
            const int MAX_RETRIES = 50;
            int retries = MAX_RETRIES;

            ClosePort();

            while (retries-- > 0)
            {
                if (Open())
                    break;
            }

            comm.WriteData(command);
            comm.ReceiveData();
            ClosePort();
        }

        #endregion

        #region Advance Mode

        /// <summary>
        /// When the Advance Mode checkbox is ticked, the shape of the form will changed
        /// and the options are shown or hidden.
        /// </summary>
        private void ChangeFormSize()
        {
            var changeY = 130;

            if (this.cbAdvancedMode.Checked)
            {
                panelHiddenMode.Visible = true;
                panelHardwarePlatform.Visible = true;
                lineShape5.Y1 += changeY;
                lineShape5.Y2 += changeY;
                this.Height += changeY;
                panelExport.Location = new Point(panelExport.Location.X, panelExport.Location.Y + changeY);
            }
            else
            {
                panelHiddenMode.Visible = false;
                panelHardwarePlatform.Visible = false;
                lineShape5.Y1 -= changeY;
                lineShape5.Y2 -= changeY;
                this.Height -= changeY;
                panelExport.Location = new Point(panelExport.Location.X, panelExport.Location.Y - changeY);
            }
        }

        /// <summary>
        /// The Advance Mode drop down list is populated according to the
        /// information contain in the zipped file.
        /// </summary>
        private void PopulateAdvancedMode()
        {
            List<string> arrayStr = new List<string>();
            var dictionnary = new Dictionary<int, string>();
            string[] list;
            string update;

            if (uploader.BinaryList != null && uploader.BinaryList.Count > 0)
            {
                // Get update versions
                for (var index = 0; index < uploader.BinaryList.Count; index++)
                {
                    list = uploader.BinaryList[index].Split('/');
                    update = uploader.Device + list[2] + " " + list[3];   // device + version

                    if (!arrayStr.Contains(update))
                        arrayStr.Add(update);
                }

                // Change the sorting order from largest to smallest.
                arrayStr.Sort();
                arrayStr.Reverse();

                // Update the dictionnary with all information found
                for (var index = 0; index < arrayStr.Count; index++)
                {
                    dictionnary.Add(index, arrayStr[index]);
                }

                // Assigned information to the drop down list
                ddlAdvanceMode.DataSource = new BindingSource(dictionnary, null);
                ddlAdvanceMode.DisplayMember = "Value";
                ddlAdvanceMode.ValueMember = "Key";
                ddlAdvanceMode.SelectedIndex = dictionnary.Count - 1;   // Select last item
            }
        }

        /// <summary>
        /// When the selected port is not STMicroelectronics, there is no platform and the
        /// Advanced Mode drop down list must be cleared.
        /// </summary>
        private void ClearAdvancedMode()
        {
            // Clear the platform value
            labelNoPlatform.Text = "";

            // Clear the model value
            labelNoModel.Text = "";

            // Clear the Advanced Mode drop down list
            ddlAdvanceMode.DataSource = null;
            ddlAdvanceMode.Items.Clear();

            // Disable checkboxes under the Advanced Mode
            cbBootloader.Checked = false;
            cbFirmware.Checked = false;
            cbFontsLibrary.Checked = false;
        }

        #endregion

        #region Build information

        /// <summary>
        /// If the application is build as a Schneider product, change its layout.
        /// </summary>
        private void ChangeVersionConfiguration()
        {
            if (Properties.Settings.Default.Version == "Schneider")
            {
                // Hide Viconics search buttons and help images
                btSearchLuaScript.Visible = false;
                btSearchStandbyImage.Visible = false;
                imgHelpExportVT.Visible = false;
                imgLogoVT.Visible = false;

                // Display Schneider and help images, search buttons and change text
                this.Icon = Properties.Resources.SE8;
                this.Text = "Uploader SE8000 rev. " + REVISION;
                uploader.Device = "SE";

                imgLogoSE.Visible = true;
                imgSearchLuaScriptSE.Visible = true;
                imgSearchStandbyImageSE.Visible = true;
                imgHelpExportSE.Visible = true;
            }
            else
            {
                // Display Viconics information
                this.Icon = Properties.Resources.VT8;
                this.Text = "Uploader VT8000 rev. " + REVISION;
                uploader.Device = "VT";
            }
        }

        /// <summary>
        /// Allow to add external dll to the application build.
        /// </summary>
        private void AddDllToBuild()
        {
            AppDomain.CurrentDomain.AssemblyResolve += (sender, args) =>
            {
                string resourceName = new AssemblyName(args.Name).Name + ".dll";
                string resource = Array.Find(this.GetType().Assembly.GetManifestResourceNames(), element => element.EndsWith(resourceName));

                using (var stream = Assembly.GetExecutingAssembly().GetManifestResourceStream(resource))
                {
                    Byte[] assemblyData = new Byte[stream.Length];
                    stream.Read(assemblyData, 0, assemblyData.Length);
                    return Assembly.Load(assemblyData);
                }
            };
        }

        #endregion

        #region Image conversion

        /// <summary>
        /// Create a directory to save the binary file and 
        /// construct the binary file name with its location
        /// <param name="fileName">The image file name with its location</param>
        /// <returns>The binary file name with its location</returns>
        /// </summary>
        private string GetImgBinLocation(string fileName)
        {
            // Define the saving folder and the file name
            string folder = GetDirectory() + @"\ImagesConverted\";
            var file = Path.GetFileNameWithoutExtension(fileName);

            // Create directory if it didn't exist
            CreateHiddenFolder(folder);

            return folder + file + ".bin";
        }

        /// <summary>
        /// Verify the image dimension and convert it in binary.
        /// <param name="standbyImage">The image file name with its location</param>
        /// </summary>
        private void CheckConvertBmpToBin(Stream stream, string standbyImage)
        {
            var fileName = GetImgBinLocation(standbyImage);

            // Verify if the binary file already exists
            if (!File.Exists(fileName))
            {
                ImageInfo imageInfo = ConvertImage.ConstructImageForConversion(stream, standbyImage, Path.GetDirectoryName(fileName));

                // If no error occurs, convert the image to a binary file
                if (imageInfo.FileFormat == GlobalError.FILE_NO_ERROR)
                {
                    if (ConvertImage.CreateBinaryFile(imageInfo))
                    {
                        UpdateStandbyField(standbyImage);
                        UpdateLogText("The image has been correctly converted");
                    }
                    else
                    {
                        this.tbStandby.Text = "";
                        UpdateLogText("Unable to convert the image");
                    }
                }
                else
                {
                    this.tbStandby.Text = "";
                    UpdateLogText(imageInfo.Message);
                }
            }
            else
            {
                // As the image is already converted, display and save the image path
                UpdateStandbyField(standbyImage);
            }
        }

        /// <summary>
        /// Update the Standby Image textbox with its location and update the User Settings.
        /// <param name="standbyImage">The image file name with its location</param>
        /// </summary>
        private void UpdateStandbyField(string standbyImage)
        {
            // Display the path in the text box
            this.tbStandby.Text = standbyImage;
            // Save the Standby Image path
            Properties.Settings.Default.StandbyImage = standbyImage;
        }

        #endregion

        #region Import/Export User Settings

        /// <summary>
        /// Import user settings from a config file when the platform is defined.
        /// </summary>
        private void ImportSettings()
        {
            // Clear the old user settings
            Properties.Settings.Default.Reset();

            if (isSupportedPlatform())
            {
                string folder = GetDirectory() + @"\" + ConfigFileName;
                var import = new SettingsIO();

                if (import.Import(this, folder))
                {
                    GetUserSettings();
                }
            }
        }

        /// <summary>
        /// When the connected device has the same platform number, verify
        /// if the recorded values still exist. If it is the case, display
        /// values in the appropriate fields.
        /// </summary>
        private void GetUserSettings()
        {
            var standbyImage = Properties.Settings.Default.StandbyImage;
            var luaScript = Properties.Settings.Default.LuaScript;
            var advanceMode = Properties.Settings.Default.AdvanceMode;

            // Verify if the BMP image still exists and convert it in a binary file
            if (standbyImage != "" && File.Exists(standbyImage))
            {
                // Convert file to Stream
                using (MemoryStream stream = new MemoryStream())
                {
                    using (Stream str = File.OpenRead(standbyImage))
                    {
                        str.CopyTo(stream);
                    }
                    // Reset memory stream
                    stream.Seek(0, SeekOrigin.Begin);
                    CheckConvertBmpToBin(stream, standbyImage);
                }
                this.tbStandby.Text = standbyImage;
            }

            // Verify if the file still exists
            if (luaScript != "" && File.Exists(luaScript))
                this.tbLuaScript.Text = luaScript;

            if (this.labelNoPlatform.Text == Properties.Settings.Default.Platform)
            {
                // Verify if it exists in the zipped file a firmware version 
                // that corresponds to the Advance Mode value
                if (advanceMode != "" && GetBinaryFileName(advanceMode, "Firmware") != "")
                    ddlAdvanceMode.SelectedIndex = ddlAdvanceMode.FindStringExact(advanceMode);
            }

            // Update check boxes
            this.cbStandBy.Checked = (Properties.Settings.Default.StandbyImageCheckBox == "True") ? true : false;
            this.cbLuaScript.Checked = (Properties.Settings.Default.LuaScriptCheckBox == "True") ? true : false;
            this.cbAdvancedMode.Checked = (Properties.Settings.Default.AdvanceModeCheckBox == "True") ? true : false;
            this.cbFirmware.Checked = (Properties.Settings.Default.FirmwareCheckBox == "True") ? true : false;
            this.cbFontsLibrary.Checked = (Properties.Settings.Default.FontsLibraryCheckBox == "True") ? true : false;
            this.cbBootloader.Checked = (Properties.Settings.Default.BootloaderCheckBox == "True") ? true : false;
        }

        /// <summary>
        /// Export user settings in a config file.
        /// </summary>
        private void ExportSettings()
        {
            if (isSupportedPlatform())
            {
                SaveUserSettings();

                string folder = GetDirectory() + @"\" + ConfigFileName;
                var export = new SettingsIO();
                export.Export(folder);
            }
        }

        /// <summary>
        /// Update the user settings before exportation.
        /// </summary>
        private void SaveUserSettings()
        {
            Properties.Settings.Default.Platform = this.labelNoPlatform.Text;
            Properties.Settings.Default.AdvanceMode = this.ddlAdvanceMode.Text;
            Properties.Settings.Default.StandbyImageCheckBox = this.cbStandBy.Checked.ToString();
            Properties.Settings.Default.LuaScriptCheckBox = this.cbLuaScript.Checked.ToString();
            Properties.Settings.Default.FirmwareCheckBox = this.cbFirmware.Checked.ToString();
            Properties.Settings.Default.FontsLibraryCheckBox = this.cbFontsLibrary.Checked.ToString();
            Properties.Settings.Default.BootloaderCheckBox = this.cbBootloader.Checked.ToString();

            if (this.cbAdvancedMode.Checked || this.cbFirmware.Checked || this.cbFontsLibrary.Checked || this.cbBootloader.Checked)
                Properties.Settings.Default.AdvanceModeCheckBox = "True";
            else
                Properties.Settings.Default.AdvanceModeCheckBox = "False";
        }

        #endregion

        #region Language

        /// <summary>
        /// Populate the language drop down list.
        /// </summary>
        private void PopulateLanguageList()
        {
            var dictionnary = new Dictionary<int, string>();
            dictionnary.Add(1, "English");
            dictionnary.Add(2, "Français");

            ddlLanguage.DataSource = new BindingSource(dictionnary, null);
            ddlLanguage.DisplayMember = "Value";
            ddlLanguage.ValueMember = "Key";
        }

        /// <summary>
        /// Identify the selected language and change fields value.
        /// </summary>
        private void PopulateFieldsWithChoosenLanguage()
        {
            // Declare Resource manager to access to specific cultureinfo
            ResourceManager resourceManager = new ResourceManager("Uploader8000.languages.Language", typeof(frmMain).Assembly);

            // Declare culture info
            CultureInfo cultureInfo = CultureInfo.CurrentCulture;

            if (ddlLanguage.Text == "Français")
            {
                cultureInfo = CultureInfo.CreateSpecificCulture("fr-CA");   // create culture for french
            }
            else if (ddlLanguage.Text == "English")
            {
                cultureInfo = CultureInfo.CreateSpecificCulture("en-US");   // create culture for english
            }

            //      MessageBox.Show("Culture Info: " + cultureInfo.ToString());

            // Allocate text to the right component
            cbAdvancedMode.Text = resourceManager.GetString("cbAdvancedMode", cultureInfo);
            labelPlatform.Text = resourceManager.GetString("labelPlatform", cultureInfo);
            labelSetup.Text = resourceManager.GetString("labelSetup", cultureInfo);
            labelUserFile.Text = resourceManager.GetString("labelUserFile", cultureInfo);
            cbStandBy.Text = resourceManager.GetString("cbStandBy", cultureInfo);
            cbLuaScript.Text = resourceManager.GetString("cbLuaScript", cultureInfo);
            cbFirmware.Text = resourceManager.GetString("cbFirmware", cultureInfo);
            cbFontsLibrary.Text = resourceManager.GetString("cbFontsLibrary", cultureInfo);
            cbBootloader.Text = resourceManager.GetString("cbBootloader", cultureInfo);
            btExport.Text = resourceManager.GetString("btExport", cultureInfo);
            labelModel.Text = resourceManager.GetString("labelModel", cultureInfo);
        }

        #endregion

        #region Log information

        // This variable is used to update the Log drop down list
        BindingList<string> outputLog = new BindingList<string>();

        // A delegate is a reference type that can be used to encapsulate a value
        private delegate void addLogDelegate(string s);
        private delegate void selectLogDelegate(Int32 i);

        /// <summary>
        /// Update the Log drop down list and set a new selected index
        /// between two threads when invoked.
        /// <param name="log">New information</param>
        /// </summary>
        public void UpdateLogText(string log)
        {
            if (this.InvokeRequired)
            {
                this.Invoke(new addLogDelegate(UpdateLogText), log);
            }
            else
            {
                outputLog.Add(log);
                SetLogSelectedIndex();
            }
        }

        /// <summary>
        /// Update the selected item between two threads when invoked.
        /// <param name="select">The object that raised the event.</param>
        /// </summary>
        private void SelectedLog(int select)
        {
            if (this.InvokeRequired)
            {
                this.Invoke(new selectLogDelegate(SelectedLog), select);
            }
            else
            {
                ddlLog.SelectedIndex = select;
            }
        }

        /// <summary>
        /// Determine the new selected item.
        /// </summary>
        private void SetLogSelectedIndex()
        {
            var selection = (ddlLog.DataSource == null) ? -1 : outputLog.Count - 1;
            SelectedLog(selection);
        }

        /// <summary>
        /// Determine which information that will be inserted into the 
        /// log drop down list.
        /// <param name="lineInformation">The new information</param>
        /// </summary>
        private void UpdateLogInformation(string lineInformation)
        {
            if (lineInformation != "")
            {
                if (lineInformation == RESET_CMD_LEVEL2)
                    UpdateLogText(uploader.UploadString + "Send a reset command level 2");
                else if (lineInformation == RESET_CMD_LEVEL1)
                    UpdateLogText(uploader.UploadString + "Send a reset command level 1");
                else if (lineInformation == ID_STR_GET_CMD)
                    UpdateLogText(uploader.UploadString + "Get the command ID string");
                //                else if (lineInformation == GET_PLATFORM_ID)
                //                    UpdateLogText("Interrogate the device for the platform value");
                //                else if (lineInformation == PLATFORM_NS)
                //                    UpdateLogText("The device platform is not supported");
                //                else if (lineInformation.IndexOf(PLATFORM_P) != -1)
                //                    UpdateLogText("Get the platform value");
                else if (lineInformation == MINIBOOT_MENU_RDY)
                    UpdateLogText(uploader.UploadString + "The mini boot menu is ready");
                else if (lineInformation == AUTOBOOT_MENU_RDY)
                    UpdateLogText(uploader.UploadString + "The auto boot menu is ready");
                else if (lineInformation == READY_TO_RCV_FILE)
                    UpdateLogText(uploader.UploadString + "Ready to receive file information");
                else if (lineInformation == SYNC_CMD_BOOT1)
                    UpdateLogText(uploader.UploadString + "Synchronize command boot 1");
                else if (lineInformation == SYNC_CMD_BOOT2)
                    UpdateLogText(uploader.UploadString + "Synchronize command boot 1");
                else if (lineInformation == SYNC_CMD_GAMMA)
                    UpdateLogText(uploader.UploadString + "Synchronize gamma command");
                else if (lineInformation == QUIT_CMD)
                    UpdateLogText(uploader.UploadString + "Quit the uploader");
                else if (lineInformation.Contains("Starting the application ...") || lineInformation.Contains("Error : "))
                    //                    || lineInformation.IndexOf("Port opened") > -1 || lineInformation.IndexOf("Port closed") > -1)
                    UpdateLogText(lineInformation);
            }
        }

        /// <summary>
        /// Save the raw information of the upload contains in the RichTextBox
        /// in a rich text file format.
        /// <param name="status">The upload status</param>
        /// </summary>
        private void SaveLogFile(string status)
        {
            // Define the saving folder
            string folder = GetDirectory() + @"\Log";
            // Set the new file file
            string fileName = @"\upload_" + status + "_" + DateTime.Now.ToString("yyMMdd_HHmmss") + ".txt";
            // Create directory if it didn't exist
            CreateFolder(folder);
            // Save information in a text format
            rtbDisplay.SaveFile(folder + fileName, RichTextBoxStreamType.PlainText);
        }

        /// <summary>
        /// Remove all logs information from the drop down list and the rich text box.
        /// </summary>
        private void ClearApplication()
        {
            uploader.LastRichTextBoxLine = 0;   // Reset counter
            ClearLog();                         // Clear the drop down list "Log"
            rtbDisplay.Clear();                 // Clear the rough log
            comm.ClearComData();                // Clear data of the communication manager
        }

        /// <summary>
        /// Clear the drop down list "Log".
        /// </summary>
        private void ClearLog()
        {
            var nbLog = outputLog.Count;
            for (var index = 0; index < nbLog; index++)
                outputLog.Remove(outputLog[0]);
        }

        #endregion

        #region Others

        /// <summary>
        /// Create a directory if it doesn't exist.
        /// </summary>
        private void CreateFolder(string folder)
        {
            if (!Directory.Exists(folder))
            {
                Directory.CreateDirectory(folder);
            }
        }

        /// <summary>
        /// Create a directory if it doesn't exist and change
        /// its attribute to hide it.
        /// </summary>
        private void CreateHiddenFolder(string folder)
        {
            CreateFolder(folder);

            DirectoryInfo dirInfo = new DirectoryInfo(folder);

            if ((dirInfo.Attributes & FileAttributes.Hidden) != FileAttributes.Hidden)
                dirInfo.Attributes |= FileAttributes.Hidden;
        }

        /// <summary>
        /// Remove a group of directories.
        /// </summary>
        private void RemoveFolders()
        {
            RemoveHiddenFolder(GetDirectory() + @"\ImagesConverted");
            RemoveHiddenFolder(GetDirectory() + @"\HiddenExtraction");
        }

        /// <summary>
        /// Remove an hidden directory if it exists.
        /// </summary>
        private void RemoveHiddenFolder(string folder)
        {
            try
            {
                if (Directory.Exists(folder))
                {
                    DirectoryInfo dirInfo = new DirectoryInfo(folder);

                    // Change directory attribute to remove the hidden
                    if ((dirInfo.Attributes & FileAttributes.Normal) != FileAttributes.Normal)
                        dirInfo.Attributes = FileAttributes.Normal;

                    dirInfo.Delete(true);   // true => recursive delete
                }
            }
            catch (IOException e)
            {
                UpdateLogText("Error : " + e.Message);
            }
        }

        /// <summary>
        /// Get the relative directory path.
        /// </summary>
        private string GetDirectory()
        {
            return Path.GetDirectoryName(Process.GetCurrentProcess().MainModule.FileName);
        }

        /// <summary>
        /// Change the cursor to wait mode when the application is working.
        /// <param name="wait">True when the application is working otherwise it's false</param>
        /// </summary>
        private void EnablingForm(bool wait)
        {
            // Disable the form
            EnableForm(!wait);
            // Change layout of the cursor to wait mode if wait is true
            Cursor.Current = (wait) ? Cursors.WaitCursor : Cursors.Arrow;
        }

        /// <summary>
        /// Disable the form during the update and enable it after the update
        /// <param name="enable">True to enable the form otherwise false to disable it</param>
        /// </summary>
        private void EnableForm(bool enable)
        {
            // Enable/Disable the start button
            btExport.Enabled = enable;

            // Enable/Disable the checkboxes
            cbStandBy.Enabled = enable;
            cbLuaScript.Enabled = enable;
            cbAdvancedMode.Enabled = enable;
            cbFirmware.Enabled = enable;
            cbFontsLibrary.Enabled = enable;
            cbBootloader.Enabled = enable;

            // Enable/Disable the drop down lists
            ddlPort.Enabled = enable;
            ddlAdvanceMode.Enabled = enable;

            if (uploader.Device == "SE")
            {
                // Enable/Disable the search
                imgSearchStandbyImageSE.Enabled = enable;
                imgSearchLuaScriptSE.Enabled = enable;

                // Enable/Disable the help
                imgHelpExportSE.Enabled = enable;
            }
            else
            {
                // Enable/Disable the search
                btSearchStandbyImage.Enabled = enable;
                btSearchLuaScript.Enabled = enable;

                // Enable/Disable the help
                imgHelpExportVT.Enabled = enable;
            }
        }

        #endregion

        #region PDF

        /// <summary>
        /// Verify if the PDF file exists and open it.
        /// <param name="fileName">PDF file name</param>
        /// </summary>
        private void OpenPDF(string fileName)
        {
            string folder = GetDirectory() + @"\Help";

            if (Directory.Exists(folder))
            {
                string[] files = Directory.GetFiles(folder, fileName);

                if (files.Length != 0 && File.Exists(files[0]))
                {
                    System.Diagnostics.Process.Start(files[0]);
                }
                else
                {
                    UpdateLogText("Error : Could not find " + fileName);
                }
            }
            else
            {
                UpdateLogText("Error : Could not find the Help directory");
            }
        }

        #endregion

        #region Platform & Model

        /// <summary>
        /// Get the platform value and the model of the connected device.
        /// </summary>
        private void GetPlatformAndModel()
        {
            GetPlatform();
            GetModel();
        }

        /// <summary>
        /// Get the platform value of the connected device.
        /// </summary>
        private void GetPlatform()
        {
            EnablingForm(true);

            // Wait before interrogating the device when an upload has been executed
            // to let the device to reboot
            if (uploader.Uploading && uploader.PortUsed != "")
                Thread.Sleep(3000);
            // Clear the whole application when interrogating the device and not during an upload
            else if (!uploader.Uploading)
                ClearApplication();

            // To find the platform value
            InterrogateDevice("platform");
            // Extract all necessary information from the zipped file
            ExtractBinaryFromZipFile();
            // Fill the advance mode drop down list with the platform value found
            PopulateAdvancedMode();
            // Import user settings from previous run to avoid user to fill the form again
            ImportSettings();

            if (uploader.Uploading && uploader.PortUsed != "")
                uploader.Uploading = false;

            EnablingForm(false);
        }

        /// <summary>
        /// Interrogate the device to know the platform value or the model value.
        /// <param name="interrogate">Received command from the device</param>
        /// </summary>
        private void InterrogateDevice(string interrogate)
        {
            // Creat a modem to communicate
            Ymodem ymodem = new Ymodem(comm, this);

            // Open COM port
            if (!CheckAndOpenComPort())
            {
                UpdateLogText("Error : Could not open or use the specified COM port when getting the " + interrogate);
                return;
            }
            else
            {
                // Clear info that will update the RichTextBox
                comm.ClearComData();

                if (interrogate == "platform")
                {
                    // Send command to have the device's platform
                    comm.WriteData(GET_PLATFORM_ID);

                    // Verify if the device is not supported
                    if (WaitDeviceReadyToContinue(ANS_PLATFORM_NS))
                    {
                        labelNoPlatform.Text = "Unsupported";
                    }
                    else
                    {
                        // Verify which device is connected
                        if (WaitDeviceReadyToContinue(ANS_PLATFORM_P))
                        {
                            if (CompareChecksum())
                                GetPlatformValue(ANS_PLATFORM_P);
                            else
                                labelNoPlatform.Text = "Unsupported";
                        }
                        else
                            labelNoPlatform.Text = "Unsupported";
                    }
                }
                else  // interrogate == "model"
                {
                    // Send command to have the device's model
                    comm.WriteData(GET_MODEL_ID);

                    // Verify if the device is not supported
                    if (WaitDeviceReadyToContinue(ANS_MODEL))
                    {
                        if (CompareChecksum())
                            GetModelValue(ANS_MODEL);
                        else
                            labelNoModel.Text = "Unknown";
                    }
                    else
                    {
                        labelNoModel.Text = "Unknown";
                    }
                }

                ClosePort();
            }
        }

        /// <summary>
        /// Extract information from the received device and populate
        /// the platform label.
        /// <param name="receivedCommand">Received command from the device</param>
        /// </summary>
        private void GetPlatformValue(string receivedCommand)
        {
            labelNoPlatform.Text = Convert.ToInt32(ExtractPayloadInformation(receivedCommand), 16).ToString();
        }

        /// <summary>
        /// Verify the actual platform is a supported platform
        /// <returns>True if the platform is supported otherwise false</returns>
        /// </summary>
        private bool isSupportedPlatform()
        {
            int myInt;
            return int.TryParse(labelNoPlatform.Text, out myInt);
        }

        /// <summary>
        /// Create a model data table to identify the device's model
        /// </summary>
        private void CreateModelTable()
        {
            // Define the data table
            model.Columns.Add("Value", typeof(int));
            model.Columns.Add("Model", typeof(string));

            // Add models with their corresponding values
            model.Rows.Add(143, "VT8350");
            model.Rows.Add(144, "VT8300");
            model.Rows.Add(145, "SE8350");
            model.Rows.Add(146, "SE8300");

            model.Rows.Add(153, "VTR8350");
            model.Rows.Add(154, "VTR8300");
            model.Rows.Add(155, "SER8350");
            model.Rows.Add(156, "SER8300");

            model.Rows.Add(160, "VT8600");
            model.Rows.Add(161, "SE8600");
            model.Rows.Add(162, "VT8650");
            model.Rows.Add(163, "SE8650");
        }

        /// <summary>
        /// Get the model of the connected device.
        /// </summary>
        private void GetModel()
        {
            EnablingForm(true);
            InterrogateDevice("model");
            EnablingForm(false);
        }

        /// <summary>
        /// Extract information from the received device and populate
        /// the model label.
        /// <param name="receivedCommand">Received command from the device</param>
        /// </summary>
        private void GetModelValue(string receivedCommand)
        {
            CompareChecksum();

            var result = Convert.ToInt32(ExtractPayloadInformation(receivedCommand), 16);

            foreach (DataRow dr in model.Rows)
            {
                if (Convert.ToInt32(dr["Value"]) == result)
                {
                    labelNoModel.Text = dr["Model"].ToString();
                    break;
                }
            }
        }

        /// <summary>
        /// Extract information from the Rich Text Box.
        /// <returns>The device answer</returns>
        /// </summary>
        private string ExtractAnswerFromRichTextBox()
        {
            // Get the response (The last RichTextBox is always empty)
            return rtbDisplay.Lines[rtbDisplay.Lines.Length - 2];
        }

        /// <summary>
        /// Find the answer part and get the payload information.
        /// <param name="receivedCommand">Received command from the device</param>
        /// <returns>The value to analyze from the device answer</returns>
        /// </summary>
        private string ExtractPayloadInformation(string receivedCommand)
        {
            return ExtractAnswerFromRichTextBox().ToString().Substring(receivedCommand.Length, 4);
        }

        /// <summary>
        /// Compare the device answer checksum to the calculated checksum from the device's answer
        /// <returns>True if the comparison is equal otherwise false</returns>
        /// </summary>
        private bool CompareChecksum()
        {
            // Get the device's answer
            var answer = ExtractAnswerFromRichTextBox();
            // Extract the checksum from the device answer
            var answerChecksum = answer.Substring(answer.Length - 3, 2);

            // Get the integral value of each character and add them.
            var decChecksum = 0;
            for (var index = 1; index < answer.Length - 3; index++)
                decChecksum += Convert.ToInt32(answer[index]);

            // Convert the decimal checksum in hexadecimal and take the last 8 bits
            var hexChecksum = String.Format("{0:X}", decChecksum);
            hexChecksum = hexChecksum.Substring(hexChecksum.Length - 2, 2);

            // Compare the evaluate checksum to the device checksum
            return (hexChecksum == answerChecksum) ? true : false;
        }

        #endregion

        #region Ports

        // This variable is used to update the port drop down list
        BindingList<string> availPorts = new BindingList<string>();

        // Warn a waiting thread that an event occurs.
        AutoResetEvent autoResetEvent = new AutoResetEvent(false);
        Thread portThread;

        // A delegate is a reference type that can be used to encapsulate a value
        private delegate void addPortDelegate(string s);
        private delegate void removePortDelegate(string s);
        private delegate void selectPortDelegate(Int32 s);

        /// <summary>
        /// Verify continuously the port device manager to detect if a new
        /// port is connected or deconnected to update the port drop down list.
        /// </summary>
        private void UpdatePortList()
        {
            while (true)
            {
                IdentifyConnectedPort();
                autoResetEvent.Set();
            }
        }

        /// <summary>
        /// Verify in the Device Manager which ports are connected.
        /// </summary>
        private void IdentifyConnectedPort()
        {
            SelectQuery serialQuery = new SelectQuery("SELECT * FROM Win32_SerialPort");
            ManagementScope connectionScope = new ManagementScope();
            ManagementObjectSearcher searcher = new ManagementObjectSearcher(connectionScope, serialQuery);
            ManagementObjectCollection searcherList = searcher.Get();
            int searcherCount = searcherList.Count;

            try
            {
                if (searcherCount > 0)
                {
                    // Remove the port not found in the Device Manager from the port list
                    if (availPorts.Count > searcherCount)
                    {
                        RemovePortFromList(searcherList);
                        SelectPort(FindPortIndex());
                    }

                    // Add the new port's found in the device manager to the port list
                    if (availPorts.Count < searcherCount)
                    {
                        AddPortToList(searcherList);
                        SetPortIndex();
                    }
                }
                else
                {
                    ClearPortList();
                }
            }
            catch (ManagementException e)
            {
                UpdateLogText("Error : " + e.Message);
            }
        }

        /// <summary>
        /// Add the new port found in the Device Manager.
        /// <param name="searcherList">The list of ports found</param>
        /// </summary>
        private void AddPortToList(ManagementObjectCollection searcherList)
        {
            // Add ports to the port's list
            foreach (ManagementObject port in searcherList)
            {
                string portName = port["DeviceID"].ToString() + " " + port["Description"].ToString();

                if (uploader.Initializing)
                {
                    AddPort(portName);
                }
                else
                {
                    if (!availPorts.Contains(portName))
                    {
                        AddPort(portName);
                        uploader.PortAdded = portName;
                    }
                }
            }
        }

        /// <summary>
        /// Add a new port to the drop down list.
        /// <param name="port">The port name</param>
        /// </summary>
        private void AddPort(string port)
        {
            if (this.InvokeRequired)
            {
                this.Invoke(new addPortDelegate(AddPort), port);
            }
            else
            {
                availPorts.Add(port);
            }
        }

        /// <summary>
        /// Remove the port not found in the Device Manager.
        /// <param name="searcherList">The list of ports found</param>
        /// </summary>
        private void RemovePortFromList(ManagementObjectCollection searcherList)
        {
            for (var index = 0; index < availPorts.Count; index++)
            {
                bool match = false;

                foreach (ManagementObject item in searcherList)
                {
                    string portName = item["DeviceID"].ToString() + " " + item["Description"].ToString();

                    if (availPorts[index].ToString() == portName)
                    {
                        match = true;
                        break;
                    }
                }

                if (!match)
                {
                    var portName = availPorts[index].ToString();
                    RemovePort(portName);
                }
            }
        }

        /// <summary>
        /// Clear the port list when there is no port in the Device Manager
        /// </summary>
        private void ClearPortList()
        {
            if (ddlPort.Items.Count > 0)
            {
                var nbPort = availPorts.Count;
                for (var index = 0; index < nbPort; index++)
                {
                    RemovePort(ddlPort.Items[0].ToString());
                }
            }
        }

        /// <summary>
        /// Remove a port from the drop down list.
        /// <param name="port">The port name</param>
        /// </summary>
        private void RemovePort(string port)
        {
            if (this.InvokeRequired)
            {
                this.Invoke(new removePortDelegate(RemovePort), port);
            }
            else
            {
                availPorts.Remove(port);

                // If the removed port is STMicroelectronics, clear the platform textbox
                if (isSTMicroelectronics(port) && uploader.PortUsed == port)
                {
                    ClearAdvancedMode();

                    if (!uploader.Uploading)
                        uploader.PortUsed = "";
                }
            }
        }

        /// <summary>
        /// Assign the selected port to the drop down list.
        /// <param name="index">The selected port</param>
        /// </summary>
        private void SelectPort(Int32 index)
        {
            if (this.InvokeRequired)
            {
                this.Invoke(new selectPortDelegate(SelectPort), index);
            }
            else
            {
                ddlPort.SelectedIndex = index;

                if (index != -1)
                {
                    var port = availPorts[index];

                    if (uploader.Uploading)
                    {
                        if (uploader.PortUsed == port)
                            GetPlatformAndModel();
                    }
                    else
                    {
                        if (isSTMicroelectronics(port))
                            GetPlatformAndModel();
                    }
                }
            }
        }

        /// <summary>
        /// Identify the new port index and set the "Port" drop down list.
        /// </summary>
        private void SetPortIndex()
        {
            // Set an index to the port's list
            if (!uploader.Initializing)
            {
                if (uploader.Uploading)
                {
                    if (uploader.PortUsed == uploader.PortAdded)
                    {
                        SelectPort(availPorts.IndexOf(uploader.PortAdded));
                    }
                }
                else
                {
                    if (uploader.PortUsed == "" && isSTMicroelectronics(uploader.PortAdded))
                    {
                        uploader.PortUsed = uploader.PortAdded;
                        SelectPort(availPorts.IndexOf(uploader.PortAdded));
                    }
                    else
                    {
                        SelectPort(FindPortIndex());
                    }
                }
            }
        }

        /// <summary>
        /// Identify which index to set. 
        /// When STMicroelectronics is found, the index will identify it
        /// otherwise it is the first item
        /// </summary>
        private Int32 FindPortIndex()
        {
            // Default index
//            int index = -1;// (availPorts.Count > 0) ? 0 : -1;
            int index = (availPorts.Count > 0) ? 0 : -1;

            if (uploader.Initializing)
            {
                // Search STMicroelectronics
                foreach (string port in availPorts)
                {
                    if (isSTMicroelectronics(port))
                    {
                        index = availPorts.IndexOf(port);
                        break;
                    }
                }
            }
            else    // A port has been removed
            {
                // If the STMicroelectronics is the removed port, find a new index 
                // that is not STMicroelectronics 
                if (uploader.PortUsed == "")
                {
                    foreach (string port in availPorts)
                    {
                        if (!isSTMicroelectronics(port))
                        {
                            index = availPorts.IndexOf(port);
                            break;
                        }
                    }
                }
                else
                {
                    // Keep the same index for the STMicroelectronics connected port
                    index = availPorts.IndexOf(uploader.PortUsed);
                }
            }

            return index;
        }

        /// <summary>
        /// Verify if the port description contains 'STMicroelectronics'.
        /// <param name="port">The selected port</param>
        /// <returns>True if the port contains 'STMicroelectronics' otherwise false</returns>
        /// </summary>
        private bool isSTMicroelectronics(string port)
        {
            return (port.IndexOf("STMicroelectronics", StringComparison.OrdinalIgnoreCase) > -1) ? true : false;
        }

        /// <summary>
        /// Extract the COM port value.
        /// <returns>The COM port value</returns>
        /// </summary>
        private string GetCommPort()
        {
            return (ddlPort.SelectedItem != null) ? ddlPort.SelectedItem.ToString().Split()[0] : "";
        }

        /// <summary>
        /// Assign the new COM port value to the Communication Manager.
        /// </summary>
        private void ReadCommPortName()
        {
            if (this.ddlPort.SelectedItem != null)
            {
                comm.PortName = GetCommPort();
            }
        }

        /// <summary>
        /// Try to open the COM port when it is not already opened.
        /// <returns>Status of the operation</returns>
        /// </summary>
        private bool CheckAndOpenComPort()
        {
            const int MAX_RETRIES = 50;
            int retries;
            bool portOpen = false;

            if (comm.isPortOpen() == false)
            {
                retries = MAX_RETRIES;
                while (retries-- > 0)
                {
                    portOpen = Open();
                    if (portOpen)
                        break;
                    Thread.Sleep(1);
                }
            }
            else
            {
                portOpen = true;
            }

            return portOpen;
        }

        /// <summary>
        /// Close the COM port.
        /// </summary>
        private void ClosePort()
        {
            try
            {
                if (comm.PortAvailable(GetCommPort()) == true)
                {
                    comm.ClosePort();
                }
            }
            catch (Exception)
            {
                ;
            }
        }

        #endregion

        #region Search

        /// <summary>
        /// Open a dialog box to choose a Lua Script.
        /// </summary>
        private void SearchLuaScript()
        {
            OpenFileDialog openFileDialogLua = new OpenFileDialog();
            openFileDialogLua.Filter = "Lua Files (*.lua)|*.lua";
            openFileDialogLua.FilterIndex = 1;

            if (openFileDialogLua.ShowDialog() == DialogResult.OK)
            {
                var filename = openFileDialogLua.FileName;

                if (VerifyExtension(filename, ".lua"))
                {
                    // Display the path in the text box
                    this.tbLuaScript.Text = filename;
                    // Save the Lua Script path
                    Properties.Settings.Default.LuaScript = filename;
                }
                else
                {
                    tbLuaScript.Text = "";    // Clear the textbox
                    UpdateLogText("Error : The Lua Script extension is not correct");
                }
            }
        }

        /// <summary>
        /// Open a dialog box to choose a Standby Image, verify the BMP dimension
        /// and convert it in a binary file.
        /// </summary>
        private void SearchStandbyImage()
        {
            if (openFileDialogStandby.ShowDialog() == DialogResult.OK)
            {
                // Get the selected file name
                var standbyImage = openFileDialogStandby.FileName;

                if (VerifyExtension(standbyImage, ".bmp"))
                {
                    // Next time open an OpenFileDialog with the directory of the file name
                    openFileDialogStandby.InitialDirectory = Path.GetDirectoryName(standbyImage);

                    CheckConvertBmpToBin(openFileDialogStandby.OpenFile(), standbyImage);
                }
                else
                {
                    tbStandby.Text = "";    // Clear the textbox
                    UpdateLogText("Error : The Standby Image extension is not correct");
                }
            }
        }

        /// <summary>
        /// Initialize the global OpenFileDialog to search Standby Images. The global variable
        /// is used in order to have an initial directory and to be able to open the last 
        /// directory used by the search Standby Images dialog.
        /// </summary>
        private void InitializeStandbyImageFileDialog()
        {
            openFileDialogStandby.InitialDirectory = @"C:\Uploader8000\Sample Standby Images";
            openFileDialogStandby.Filter = "Image Files (*.bmp)|*.bmp";
            openFileDialogStandby.FilterIndex = 1;
            openFileDialogStandby.Multiselect = false; // Allow only one selection
        }

        /// <summary>
        /// Verify that the extension has not been changed by the user.
        /// <returns>True if the extension is correct otherwise false</returns>
        /// </summary>
        private bool VerifyExtension(string fileName, string extension)
        {
            return string.Equals(Path.GetExtension(fileName), extension, StringComparison.OrdinalIgnoreCase);
        }

        #endregion

        #region Upload

        /// <summary>
        /// The uploading sequence to update the device
        /// <returns>True if the process succeed otherwise false</returns>
        /// </summary>
        private bool UploadSequence()
        {
            // Status of the upload
            bool uploadStatus = true;

            // If the bootloader is selected, start the device's upload
            if (cbBootloader.Checked)
            {
                // Verify the application identifier and its compatibility
                if (GetAppIDAndCheckCompatibility())
                    uploadStatus = UploadSelection("Bootloader");
                else
                    uploadStatus = false;

                CloseUpload();
                QuitCmd(QUIT_CMD);
            }

            if (uploadStatus)
            {
                // Wait 5 seconds if a Bootloader upload has been completed before to continue any uploads
                if (cbBootloader.Checked)
                    Thread.Sleep(5000);

                // Verify the application identifier and its compatibility
                if (GetAppIDAndCheckCompatibility())
                {
                    // If the firmware is selected, upload the device
                    if (cbFirmware.Checked)
                        uploadStatus = UploadSelection("Firmware");

                    // If the bootloader is selected, upload the device
                    if (uploadStatus && cbStandBy.Checked)
                        uploadStatus = UploadSelection("Standby Image");

                    // If the Lua Script is selected, upload the device
                    if (uploadStatus && cbLuaScript.Checked)
                        uploadStatus = UploadSelection("Lua Script");

                    // If the fonts library is selected, upload the device
                    if (uploadStatus && cbFontsLibrary.Checked)
                        uploadStatus = UploadSelection("Fonts Library");
                }
                else
                {
                    uploadStatus = false;
                }

                // Wait to let the process to complete
                Thread.Sleep(1500);

                uploader.UploadString = ""; // Clear the variable when the upload is completed
                CloseUpload();
                QuitCmd(QUIT_CMD);
            }

            return uploadStatus;
        }

        /// <summary>
        /// Upload the selection ticked by the user 
        /// <param name="upload">Selection to be updated</param>
        /// <returns>True if the process succeed otherwise false</returns>
        /// </summary>
        private bool UploadSelection(string upload)
        {
            var uploadStatus = true;

            uploader.UploadString = upload + " : ";
            UpdateLogText(uploader.UploadString + "Start the upload");

            if (upload == "Bootloader")
                uploadStatus = UploadBootLoader();
            else if (upload == "Firmware")
                uploadStatus = UploadFirmware();
            else if (upload == "Standby Image")
                uploadStatus = UpldoadStandByImage();
            else if (upload == "Lua Script")
                uploadStatus = UploadLuaScript();
            else // (upload == "Fonts Library")
                uploadStatus = UploadFontsLibrary();

            UpdateLogText((uploadStatus) ? uploader.UploadString + "Upload is completed" : uploader.UploadString + "Error : Fail to update the device");
            return uploadStatus;
        }

        /// <summary>
        /// Operations to communicate with the device 
        /// <param name="reset_cmd">Reset command to prepare the device to communicate</param>
        /// <param name="upload_cmd">Upload command to tell wich upload will be executed</param>
        /// <param name="answer_to_wait_on">Answer to wait for before to proceed to the upload</param>
        /// <param name="filename">File that contains information to upload the application</param>
        /// <returns>True if the process succeed otherwise false</returns>
        /// </summary>
        private bool UploadFile(string reset_cmd, string upload_cmd, string answer_to_wait_on, string filename)
        {
            Ymodem ymodem = new Ymodem(comm, this);
            bool uploadStatus = false;

            comm.ClearComData();

            if (uploader.CurrentAppID == SYNC_CMD_GAMMA)
            {
                uploadStatus = SendResetAndWaitDeviceReady(reset_cmd);

                if (uploadStatus)
                {
                    uploadStatus = WaitDeviceReadyToContinue(answer_to_wait_on);

                    if (uploadStatus)
                    {
                        comm.WriteData(upload_cmd);
                        uploadStatus = WaitDeviceReadyToContinue(READY_TO_RCV_FILE);

                        if (uploadStatus)
                        {
                            uploadStatus = ymodem.YmodemUploadFile(filename);
                            comm.ReceiveData();
                        }
                    }
                }
            }
            else if ((uploader.CurrentAppID == SYNC_CMD_BOOT1) || (uploader.CurrentAppID == SYNC_CMD_BOOT2))
            {
                comm.WriteData(upload_cmd);
                uploadStatus = WaitDeviceReadyToContinue(READY_TO_RCV_FILE);

                if (uploadStatus)
                {
                    uploadStatus = ymodem.YmodemUploadFile(filename);
                    comm.ReceiveData();
                }
            }
            else
            {
                uploadStatus = false;
            }

            comm.ClearComData();
            return uploadStatus;
        }

        /// <summary>
        /// Upload the Standby Image
        /// <returns>True if the process succeed otherwise false</returns>
        /// </summary>
        private bool UpldoadStandByImage()
        {
            return UploadFile(RESET_CMD_LEVEL2, LOAD_CUSTOM_IMG_CMD, AUTOBOOT_MENU_RDY, GetImgBinLocation(Properties.Settings.Default.StandbyImage));
        }

        /// <summary>
        /// Upload the Lua Script
        /// <returns>True if the process succeed otherwise false</returns>
        /// </summary>
        private bool UploadLuaScript()
        {
            return UploadFile(RESET_CMD_LEVEL2, LOAD_LUA_CMD, AUTOBOOT_MENU_RDY, Properties.Settings.Default.LuaScript);
        }

        /// <summary>
        /// Upload the Firmware
        /// <returns>True if the process succeed otherwise false</returns>
        /// </summary>
        private bool UploadFirmware()
        {
            var fileName = GetBinaryFile(this.ddlAdvanceMode.Text, "Firmware");
            return (fileName == "") ? false : UploadFile(RESET_CMD_LEVEL2, LOAD_FIRMWARE_CMD, AUTOBOOT_MENU_RDY, fileName);
        }

        /// <summary>
        /// Upload the Fonts Library
        /// <returns>True if the process succeed otherwise false</returns>
        /// </summary>
        private bool UploadFontsLibrary()
        {
            var fileName = GetBinaryFile(this.ddlAdvanceMode.Text, "Fonts");
            return (fileName == "") ? false : UploadFile(RESET_CMD_LEVEL2, LOAD_FONTS_LIB_CMD, AUTOBOOT_MENU_RDY, fileName);
        }

        /// <summary>
        /// Upload the Boot loader
        /// <returns>True if the process succeed otherwise false</returns>
        /// </summary>
        private bool UploadBootLoader()
        {
            var fileName = GetBinaryFile(this.ddlAdvanceMode.Text, "Bootloader");
            return (fileName == "") ? false : UploadFile(RESET_CMD_LEVEL1, LOAD_AUTO_BOOTLOADER, MINIBOOT_MENU_RDY, fileName);
        }

        #endregion

        #region Validate user choices

        /// <summary>
        /// Multiple verifications before to start the upload.
        /// <returns>True if all validations succeed otherwise false</returns>
        /// </summary>
        private bool ValidateSelection()
        {
            bool pass = true;

            if ((cbBootloader.Checked == false) &&
               ((cbFontsLibrary.Checked == false) &&
                (cbLuaScript.Checked == false) &&
                (cbFirmware.Checked == false) &&
                (cbStandBy.Checked == false)))
            {
                UpdateLogText("Error : No valid operation was selected");
                pass = false;
            }

            if (cbBootloader.Checked == true && this.ddlAdvanceMode.Text == string.Empty)
            {
                UpdateLogText("Error : Invalid Boot loader selection because no zipped file found");
                pass = false;
            }

            if (cbFirmware.Checked == true && this.ddlAdvanceMode.Text == string.Empty)
            {
                UpdateLogText("Error : Invalid Firmware selection because no zipped file found");
                pass = false;
            }

            if (cbFontsLibrary.Checked == true && cbFirmware.Checked == false)
            {
                UpdateLogText("Error : Fonts Library could not be updated without the Firmware");
                pass = false;
            }

            if (cbFontsLibrary.Checked == true && this.ddlAdvanceMode.Text == string.Empty)
            {
                UpdateLogText("Error : Invalid Fonts Library selection because no zipped file found");
                pass = false;
            }

            if (cbStandBy.Checked == true && this.tbStandby.Text == string.Empty)
            {
                UpdateLogText("Error : No Standby image file has been selected");
                pass = false;
            }

            if (cbStandBy.Checked == true && !File.Exists(GetImgBinLocation(this.tbStandby.Text)))
            {
                UpdateLogText("Error : Could not find the binary file of the image. Try to convert it again");
                pass = false;
            }

            if (cbLuaScript.Checked == true && (this.tbLuaScript.Text == string.Empty || !VerifyExtension(tbLuaScript.Text, ".lua")))
            {
                UpdateLogText("Error : No Lua script file has been selected");
                pass = false;
            }

            if (!isSTMicroelectronics(ddlPort.Text))
            {
                UpdateLogText("Error : Invalid COM port");
                pass = false;
            }

            if (!isSupportedPlatform())
            {
                UpdateLogText("Error : The actual platform is not supported");
                pass = false;
            }

            return pass;
        }

        #endregion

        #region Zipped file

        /// <summary>
        /// Locate the zipped file.
        /// <returns>The location of the zipped file</returns>
        /// </summary>
        public string GetZipFileLocation()
        {
            string folder = GetDirectory() + @"\";
            string[] files = Directory.GetFiles(folder, ZipFileName);
            return (files.Length > 0) ? files[0] : "";
        }

        /// <summary>
        /// Extract all binaries in the zipped file that correspond to the device platform.
        /// </summary>
        public void ExtractBinaryFromZipFile()
        {
            string platform = "P" + labelNoPlatform.Text;
            string zipFileLocation = GetZipFileLocation();
            string zipExtractPath = GetDirectory() + @"\HiddenExtraction";

            try
            {
                // Create and change directory attribute
                CreateHiddenFolder(zipExtractPath);

                // Clear the binary list
                if (uploader.BinaryList.Count > 0)
                    uploader.BinaryList.Clear();

                // Verify that the platform textbox value is not null, verify the zipped file
                if (!string.IsNullOrEmpty(platform))
                {
                    // Verify if the Zipped file exists
                    if (zipFileLocation.Length != 0 && File.Exists(zipFileLocation))
                    {
                        // Read the Zipped file
                        using (ZipFile zip = ZipFile.Read(zipFileLocation))
                        {
                            // Parse each entry found
                            foreach (ZipEntry entry in zip)
                            {
                                // Verify if the file is encrypted to exclude folders and
                                // compare the platform to keep the right binary files
                                if (entry.UsesEncryption && entry.FileName.Split('/')[1] == platform)
                                {
                                    string binaryFile = zipExtractPath + @"\" + entry.FileName.Replace("/", "\\");

                                    if (!File.Exists(binaryFile))
                                    {
                                        entry.ExtractWithPassword(zipExtractPath, ZipPassword.Substring(14, 39));
                                    }

                                    // Keep the binary path
                                    uploader.BinaryList.Add(entry.FileName);
                                }
                            }
                        }
                    }
                    else
                    {
                        uploader.Message = "Error : Could not find the zipped file that contains binary files";
                    }
                }
                else
                {
                    uploader.Message = "Error : The platform is not defined";
                }
            }
            catch (Exception e)
            {
                uploader.Message = "Error : " + e.Message;
            }

            if (uploader.Message != "")
            {
                UpdateLogText(uploader.Message);
                uploader.Message = "";  // Erase the message
            }
        }

        /// <summary>
        /// Verify if the device number and the update version are in the zipped file
        /// <param name="version">The selected version choose by the user with the drop down list</param>
        /// <param name="selection">The upload choosen by the user with checkboxes</param>
        /// <returns>The binary file name</returns>
        /// </summary>
        private string GetBinaryFileName(string version, string selection)
        {
            string[] select = version.Split();
            string value = select[0].Remove(0, 2); // Remove the first two characters (SE or VT)
            string fileName = "";

            for (var index = 0; index < uploader.BinaryList.Count; index++)
            {
                // Find the binary file that satisfy the user selections
                // which is the checkbox and the advance mode drop down list
                if (uploader.BinaryList[index].Contains(selection) && uploader.BinaryList[index].Contains(value) && uploader.BinaryList[index].Contains(select[1]))
                {
                    fileName = uploader.BinaryList[index];
                    break;
                }
            }

            return fileName;
        }

        /// <summary>
        /// Extract from the zipped file, the binary file that will be used during the upload
        /// <param name="version">The selected version choose by the user with the drop down list</param>
        /// <param name="selection">The upload choosen by the user with checkboxes</param>
        /// <returns>The binary file location that has been extracted</returns>
        /// </summary>
        private string GetBinaryFile(string version, string selection)
        {
            string fileName = GetBinaryFileName(version, selection);
            string zipExtractPath = GetDirectory() + @"\HiddenExtraction";
            string binaryFile = zipExtractPath + @"\" + fileName.Replace("/", "\\");
            bool fileExists = File.Exists(binaryFile);

            if (!fileExists)
                UpdateLogText(uploader.UploadString + "Error : Unable to find the binary file");

            return (fileExists) ? binaryFile : "";
        }

        #endregion

    }

    #region Define class

    /// <summary>
    /// Class to define the uploader variables.
    /// </summary>
    public class Uploader
    {
        // Indicate when the application is initializing
        public bool Initializing = false;

        // Indicate when the application is uploading
        public bool Uploading = false;

        // Indicate which upload is active
        public string UploadString = "";

        // The current application identifier (used during the upload)
        public string CurrentAppID = "";

        // Prefix used to dispay the Advance Mode version (Viconics = VT and SE = Schneider)
        public string Device = "";

        // Message to be displayed into the "Log" drop down list
        public string Message = "";

        // Memorize the port added to find its index
        public string PortAdded = "";

        // Memorize the port used to recover it during the uploading
        public string PortUsed = "";

        // The binary list extracted from the zipped file
        public List<string> BinaryList = new List<string>();

        // The value of the last line of the Rich Text Box
        public int LastRichTextBoxLine = 0;
    }

    #endregion

}
